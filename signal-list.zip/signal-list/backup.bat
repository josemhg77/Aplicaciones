@echo off
setlocal
:: Formato de fecha YYYY-MM-DD
set "datestr=%date:~-4%-%date:~3,2%-%date:~0,2%"
:: Formato de hora HH-MM-SS
set "timestr=%time:~0,2%-%time:~3,2%-%time:~6,2%"
set "timestr=%timestr: =0%"
set "filename=signal-list-backup_%datestr%_%timestr%.zip"

if not exist "backups" mkdir "backups"

echo Creando backup en formato ZIP: %filename%...

:: Comprimimos todos los ficheros de la carpeta actual excluyendo la carpeta 'backups' y este propio script
powershell -Command "$files = Get-ChildItem -Path . -Exclude @('backups', 'backup.bat'); if ($files) { Compress-Archive -Path $files -DestinationPath 'backups\%filename%' -Force }"

if %ERRORLEVEL% equ 0 (
    echo.
    echo [OK] Backup creado con exito en 'backups\%filename%'
) else (
    echo.
    echo [ERROR] Hubo un problema al crear el backup.
)

pause
