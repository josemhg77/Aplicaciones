// ============================================================
// Signal List Generator — Main Logic
// Each row = one signal with columns:
// Tag, Descripción, Tipo Señal, Rango, Unidades, Alarma, Notas, Revisión
// Duplicate tags are highlighted in red.
// ============================================================

(function () {
    'use strict';

    // ----------------------------------------------------------
    // Signal database: industrial standard typicals (Read-only reference)
    // ----------------------------------------------------------
    const INDUSTRIAL_DEFAULTS = {
        'Presión': [
            { suffix: 'PV', desc: 'Variable de proceso presión', type: 'AI', range: '4-20 mA', unit: 'bar', alarm: '0=alarma', notes: '' },
            { suffix: 'H', desc: 'Alarma alta presión', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'H', notes: '' },
            { suffix: 'L', desc: 'Alarma baja presión', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'L', notes: '' }
        ],
        'Temperatura': [
            { suffix: 'PV', desc: 'Variable de proceso temperatura', type: 'AI', range: '4-20 mA / PT100', unit: '°C', alarm: '0=alarma', notes: '' },
            { suffix: 'H', desc: 'Alarma alta temperatura', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'H', notes: '' },
            { suffix: 'L', desc: 'Alarma baja temperatura', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'L', notes: '' }
        ],
        'Caudal': [
            { suffix: 'PV', desc: 'Variable de proceso caudal', type: 'AI', range: '4-20 mA', unit: 'm³/h', alarm: '0=alarma', notes: '' },
            { suffix: 'TOT', desc: 'Totalizado caudal', type: 'AI', range: '4-20 mA', unit: 'm³', alarm: '0=alarma', notes: '' },
            { suffix: 'H', desc: 'Alarma alta caudal', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'H', notes: '' }
        ],
        'Nivel': [
            { suffix: 'PV', desc: 'Variable de proceso nivel', type: 'AI', range: '4-20 mA', unit: '%', alarm: '0=alarma', notes: '' },
            { suffix: 'HH', desc: 'Alarma muy alta nivel', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'HH', notes: '' },
            { suffix: 'H', desc: 'Alarma alta nivel', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'H', notes: '' },
            { suffix: 'L', desc: 'Alarma baja nivel', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'L', notes: '' },
            { suffix: 'LL', desc: 'Alarma muy baja nivel', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'LL', notes: '' }
        ],
        'Analizador': [
            { suffix: 'PV', desc: 'Variable de proceso analizador', type: 'AI', range: '4-20 mA', unit: 'ppm', alarm: '0=alarma', notes: '' },
            { suffix: 'ST', desc: 'Estado analizador', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'FL', desc: 'Fallo analizador', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' },
            { suffix: 'CAL', desc: 'Orden calibración', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' }
        ],
        'Válvula todo nada': [
            { suffix: 'OPN', desc: 'Orden abrir válvula', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'CLS', desc: 'Orden cerrar válvula', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'ZSO', desc: 'Confirmación abierta', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'ZSC', desc: 'Confirmación cerrada', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'ZSC', notes: '' },
            { suffix: 'FL', desc: 'Fallo válvula', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' }
        ],
        'Válvula de control': [
            { suffix: 'POS', desc: 'Posición actual válvula', type: 'AI', range: '4-20 mA', unit: '%', alarm: '0=alarma', notes: '' },
            { suffix: 'SP', desc: 'Consigna posición', type: 'AO', range: '4-20 mA', unit: '%', alarm: '0=alarma', notes: '' },
            { suffix: 'ZSO', desc: 'Confirmación abierta', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'ZSC', desc: 'Confirmación cerrada', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'ZSC', notes: '' },
            { suffix: 'FL', desc: 'Fallo válvula', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' }
        ],
        'Electroválvula': [
            { suffix: 'CMD', desc: 'Orden apertura', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'RUN', desc: 'Confirmación apertura', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' }
        ],
        'Motor': [
            { suffix: 'CMD', desc: 'Orden marcha motor', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'STP', desc: 'Orden paro motor', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'RUN', desc: 'Marcha confirmada', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'FL', desc: 'Fallo motor', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' },
            { suffix: 'I', desc: 'Corriente motor', type: 'AI', range: '4-20 mA', unit: 'A', alarm: '0=alarma', notes: '' }
        ],
        'Motor con variador': [
            { suffix: 'CMD', desc: 'Orden marcha motor', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'STP', desc: 'Orden paro motor', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'RUN', desc: 'Marcha confirmada', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'FL', desc: 'Fallo motor', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' },
            { suffix: 'I', desc: 'Corriente motor', type: 'AI', range: '4-20 mA', unit: 'A', alarm: '0=alarma', notes: '' },
            { suffix: 'SP', desc: 'Consigna frecuencia', type: 'AO', range: '4-20 mA', unit: 'Hz', alarm: '0=alarma', notes: '' },
            { suffix: 'PV', desc: 'Frecuencia real', type: 'AI', range: '4-20 mA', unit: 'Hz', alarm: '0=alarma', notes: '' },
            { suffix: 'FLV', desc: 'Fallo variador', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FLV', notes: '' }
        ],
        'Motor con arrancador': [
            { suffix: 'CMD', desc: 'Orden marcha motor', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'RUN', desc: 'Marcha confirmada', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'FL', desc: 'Fallo motor', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' }
        ],
        'Ventilador': [
            { suffix: 'CMD', desc: 'Orden marcha ventilador', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'STP', desc: 'Orden paro ventilador', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'RUN', desc: 'Marcha confirmada', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'FL', desc: 'Fallo ventilador', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' }
        ],
        'Cinta transportadora': [
            { suffix: 'CMD', desc: 'Orden marcha cinta', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'STP', desc: 'Orden paro cinta', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'RUN', desc: 'En marcha', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'SWAY', desc: 'Desvío de banda', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'SWAY', notes: '' },
            { suffix: 'PULL', desc: 'Tirón de cuerda', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'PULL', notes: '' },
            { suffix: 'TENS', desc: 'Fallo tensado', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'TENS', notes: '' },
            { suffix: 'SP', desc: 'Consigna velocidad', type: 'AO', range: '4-20 mA', unit: 'm/s', alarm: '0=alarma', notes: '' },
            { suffix: 'PV', desc: 'Velocidad actual', type: 'AI', range: '4-20 mA', unit: 'm/s', alarm: '0=alarma', notes: '' }
        ],
        'Tanque': [
            { suffix: 'LSH', desc: 'Nivel alto tanque', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'H', notes: '' },
            { suffix: 'LSL', desc: 'Nivel bajo tanque', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'L', notes: '' }
        ],
        'Depósito': [
            { suffix: 'LSH', desc: 'Nivel alto depósito', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'H', notes: '' },
            { suffix: 'LSL', desc: 'Nivel bajo depósito', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'L', notes: '' }
        ],
        'Centralita de gas': [
            { suffix: 'PV', desc: 'Nivel gas', type: 'AI', range: '4-20 mA', unit: 'ppm', alarm: '0=alarma', notes: '' },
            { suffix: 'FL', desc: 'Fallo centralita', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' },
            { suffix: 'AL1', desc: 'Alarma nivel 1', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'AL1', notes: '' },
            { suffix: 'AL2', desc: 'Alarma nivel 2', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'AL2', notes: '' }
        ],
        'Centralita contraincendios': [
            { suffix: 'FIRE', desc: 'Alarma incendio', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FIRE', notes: '' },
            { suffix: 'FL', desc: 'Fallo centralita', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' }
        ],
        'Interruptor motorizado': [
            { suffix: 'OPN', desc: 'Orden apertura', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'CLS', desc: 'Orden cierre', type: 'DO', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'ZSO', desc: 'Confirmación abierto', type: 'DI', range: 'ON/OFF', unit: '', alarm: '0=alarma', notes: '' },
            { suffix: 'ZSC', desc: 'Confirmación cerrado', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'ZSC', notes: '' },
            { suffix: 'FL', desc: 'Fallo interruptor', type: 'DI', range: 'ON/OFF', unit: '', alarm: 'FL', notes: '' }
        ]
    };

    // Current types in the application (including icon and color)
    let EQUIPMENT_TYPES = [
        { name: 'Presión', icon: '🔴', color: '#f85149' },
        { name: 'Temperatura', icon: '🟠', color: '#f0883e' },
        { name: 'Caudal', icon: '🟡', color: '#e3b341' },
        { name: 'Nivel', icon: '🔵', color: '#4cc2ff' },
        { name: 'Analizador', icon: '🟣', color: '#bc8cff' },
        { name: 'Válvula todo nada', icon: '🟢', color: '#3fb950' },
        { name: 'Válvula de control', icon: '🔘', color: '#2196f3' },
        { name: 'Electroválvula', icon: '⚡', color: '#ffeb3b' },
        { name: 'Motor', icon: '⚪', color: '#8b949e' },
        { name: 'Motor con variador', icon: '🌀', color: '#00bcd4' },
        { name: 'Motor con arrancador', icon: '🚀', color: '#ff9800' },
        { name: 'Ventilador', icon: '🟤', color: '#a87058' },
        { name: 'Cinta transportadora', icon: '🛤️', color: '#795548' },
        { name: 'Tanque', icon: '🛢️', color: '#607d8b' },
        { name: 'Depósito', icon: '🧱', color: '#9e9e9e' },
        { name: 'Centralita de gas', icon: '☣️', color: '#ff5722' },
        { name: 'Centralita contraincendios', icon: '🔥', color: '#f44336' },
        { name: 'Interruptor motorizado', icon: '🔌', color: '#4caf50' }
    ];

    let SIGNAL_DB = JSON.parse(JSON.stringify(INDUSTRIAL_DEFAULTS)); // Deep clone of defaults

    const getCSSColor = (type) => {
        const found = EQUIPMENT_TYPES.find(t => t.name === type);
        return found ? found.color : '#8b949e';
    };

    // ----------------------------------------------------------
    // Application state
    // ----------------------------------------------------------
    let equipments = []; // { id, tag, desc, type, area }
    let signals = [];    // { id, eqId, tag, desc, sigType, range, unit, alarm, notes, rev }
    let nextEqId = 1;
    let nextSigId = 1;
    let editingSigId = null;
    let addingForEqId = null;

    // Template state for modal
    let currentTemplateSignals = []; // Local copy being edited in modal

    // Login State
    let isLoggedIn = false;
    const ADMIN_USER = 'jmg';
    const ADMIN_PASS = '4321';

    // ----------------------------------------------------------
    // DOM references
    // ----------------------------------------------------------
    const $ = sel => document.querySelector(sel);
    const eqTag = $('#eqTag'), eqDesc = $('#eqDesc'), eqType = $('#eqType'), eqArea = $('#eqArea');
    const bulkAddToggle = $('#bulkAddToggle'), eqTagStart = $('#eqTagStart'), eqTagEnd = $('#eqTagEnd');
    const singleTagContainer = $('#singleTagContainer'), bulkTagContainer = $('#bulkTagContainer');
    const btnAdd = $('#btnAddEquipment');
    const btnNew = $('#btnNew'), btnSave = $('#btnSave'), fileLoad = $('#fileLoad');
    const btnExportExcel = $('#btnExportExcel'), btnExportCSV = $('#btnExportCSV');
    const btnImportExcel = $('#btnImportExcel'), btnImportCSV = $('#btnImportCSV');
    const excelLoad = $('#excelLoad'), csvLoad = $('#csvLoad');
    const btnClearAll = $('#btnClearAll');
    const equipmentListEl = $('#equipmentList');
    const equipmentCountEl = $('#equipmentCount');
    const signalTable = $('#signalTable');
    const signalTableBody = $('#signalTableBody');
    const emptyMainState = $('#emptyMainState');
    const statTotal = $('#statTotal'), statAI = $('#statAI'), statAO = $('#statAO'), statDI = $('#statDI'), statDO = $('#statDO'), statCOM = $('#statCOM');
    const marginPercent = $('#marginPercent');
    const sidebarEl = $('#sidebar');

    // Edit signal modal
    const modalOverlay = $('#modalOverlay');
    const modalClose = $('#modalClose'), modalCancel = $('#modalCancel'), modalSave = $('#modalSave');
    const modalTagInput = $('#modalTag'), modalDescInput = $('#modalDesc'), modalSigTypeSelect = $('#modalSigType');
    const modalRangeInput = $('#modalRange'), modalUnitInput = $('#modalUnit'), modalAlarmInput = $('#modalAlarm');
    const modalNotesInput = $('#modalNotes'), modalRevInput = $('#modalRev');

    // Add signal modal (custom signal to existing eq)
    const addOverlay = $('#addSignalModalOverlay');
    const addClose = $('#addSignalModalClose'), addCancel = $('#addSignalModalCancel'), addSave = $('#addSignalModalSave');
    const addTagInput = $('#addModalTag'), addDescInput = $('#addModalDesc'), addSigTypeSelect = $('#addModalSigType');
    const addRangeInput = $('#addModalRange'), addUnitInput = $('#addModalUnit'), addAlarmInput = $('#addModalAlarm');
    const addNotesInput = $('#addModalNotes'), addRevInput = $('#addModalRev');

    // Template Editor Modal
    const btnEditTemplates = $('#btnEditTemplates');
    const templateOverlay = $('#templateModalOverlay');
    const templateClose = $('#templateModalClose'), templateCancel = $('#templateModalCancel'), templateSave = $('#templateModalSave');
    const templateTypeSelect = $('#templateTypeSelect');
    const templateTableBody = $('#templateTableBody');
    const btnAddTemplateRow = $('#btnAddTemplateRow');
    const btnLoadIndustrial = $('#btnLoadIndustrial');

    // Manage Types Modal
    const btnManageTypes = $('#btnManageTypes');
    const manageOverlay = $('#manageTypesModalOverlay');
    const manageClose = $('#manageTypesModalClose'), manageCloseBtn = $('#manageTypesModalCloseBtn');
    const typesListContainer = $('#typesListContainer');
    const newTypeName = $('#newTypeName'), newTypeIcon = $('#newTypeIcon'), newTypeColor = $('#newTypeColor');
    const btnAddNewType = $('#btnAddNewType');

    // Login Modal
    const btnLogin = $('#btnLogin');
    const loginOverlay = $('#loginModalOverlay');
    const loginClose = $('#loginModalClose'), loginCancel = $('#loginCancel'), loginSubmit = $('#loginSubmit');
    const loginUserInput = $('#loginUser'), loginPassInput = $('#loginPass'), loginError = $('#loginError');
    const loginBtnText = $('#loginBtnText'), loginBtnIcon = $('#loginBtnIcon');

    // ----------------------------------------------------------
    // Detect duplicate tags
    // ----------------------------------------------------------
    function getDuplicateTags() {
        const counts = {};
        signals.forEach(s => {
            const t = s.tag.trim().toUpperCase();
            if (t) counts[t] = (counts[t] || 0) + 1;
        });
        const dupes = new Set();
        for (const [t, c] of Object.entries(counts)) { if (c > 1) dupes.add(t); }
        return dupes;
    }

    // ----------------------------------------------------------
    // Render functions
    // ----------------------------------------------------------
    function renderEquipmentList() {
        equipmentCountEl.textContent = equipments.length;
        if (equipments.length === 0) {
            equipmentListEl.innerHTML = '<div class="empty-state"><span class="empty-icon">📋</span><p>No hay equipos añadidos.<br>Usa el formulario para comenzar.</p></div>';
            return;
        }
        equipmentListEl.innerHTML = '';
        equipments.forEach(eq => {
            const color = getCSSColor(eq.type);
            const sigCount = signals.filter(s => s.eqId === eq.id).length;
            const div = document.createElement('div');
            div.className = 'eq-item';
            div.style.borderLeftColor = color;
            div.innerHTML = `<div class="eq-color" style="background:${color}"></div>
                <div class="eq-info"><div class="eq-tag">${esc(eq.tag)}</div><div class="eq-type">${esc(eq.type)} · ${sigCount} señales</div></div>
                <button class="eq-add-signal" title="Añadir señal personalizada" data-id="${eq.id}">＋</button>
                <button class="eq-delete" title="Eliminar equipo" data-id="${eq.id}">✕</button>`;
            equipmentListEl.appendChild(div);
        });
        equipmentListEl.querySelectorAll('.eq-delete').forEach(btn => {
            btn.addEventListener('click', e => { e.stopPropagation(); removeEquipment(parseInt(btn.dataset.id)); });
        });
        equipmentListEl.querySelectorAll('.eq-add-signal').forEach(btn => {
            btn.addEventListener('click', e => { e.stopPropagation(); openAddModal(parseInt(btn.dataset.id)); });
        });
    }

    function renderSignalTable() {
        if (signals.length === 0) {
            signalTable.style.display = 'none';
            emptyMainState.style.display = 'flex';
            return;
        }
        signalTable.style.display = 'table';
        emptyMainState.style.display = 'none';

        const dupes = getDuplicateTags();
        signalTableBody.innerHTML = '';

        signals.forEach(sig => {
            const isDupe = dupes.has(sig.tag.trim().toUpperCase());
            const tr = document.createElement('tr');
            if (isDupe) tr.classList.add('duplicate-tag');
            tr.innerHTML = `
                <td class="col-tag">${esc(sig.tag)}</td>
                <td class="col-desc">${esc(sig.desc)}</td>
                <td class="col-sigtype">
                    <select class="inline-select" data-id="${sig.id}">
                        <option value="AI" ${sig.sigType === 'AI' ? 'selected' : ''}>AI</option>
                        <option value="AO" ${sig.sigType === 'AO' ? 'selected' : ''}>AO</option>
                        <option value="DI" ${sig.sigType === 'DI' ? 'selected' : ''}>DI</option>
                        <option value="DO" ${sig.sigType === 'DO' ? 'selected' : ''}>DO</option>
                        <option value="COM" ${sig.sigType === 'COM' ? 'selected' : ''}>COM</option>
                    </select>
                </td>
                <td class="col-range">${esc(sig.range)}</td>
                <td class="col-unit">${esc(sig.unit)}</td>
                <td class="col-alarm">${esc(sig.alarm)}</td>
                <td class="col-notes">${esc(sig.notes)}</td>
                <td class="col-rev">${esc(sig.rev)}</td>
                <td class="col-actions"><div class="row-actions">
                    <button class="btn-edit" title="Editar" data-id="${sig.id}">✏️</button>
                    <button class="btn-delete-row" title="Eliminar" data-id="${sig.id}">🗑</button>
                </div></td>`;
            signalTableBody.appendChild(tr);
        });

        signalTableBody.querySelectorAll('.inline-select').forEach(sel => {
            sel.addEventListener('change', (e) => {
                const sigId = parseInt(sel.dataset.id);
                const sig = signals.find(s => s.id === sigId);
                if (sig) {
                    sig.sigType = e.target.value;
                    renderAll();
                }
            });
        });

        signalTableBody.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click', () => openEditModal(parseInt(btn.dataset.id)));
        });
        signalTableBody.querySelectorAll('.btn-delete-row').forEach(btn => {
            btn.addEventListener('click', () => {
                signals = signals.filter(s => s.id !== parseInt(btn.dataset.id));
                renderAll();
            });
        });

        renderSignalTableFooter();
    }

    function renderSignalTableFooter() {
        let tfoot = signalTable.querySelector('tfoot');
        if (!tfoot) {
            tfoot = document.createElement('tfoot');
            signalTable.appendChild(tfoot);
        }

        const counts = { AI: 0, AO: 0, DI: 0, DO: 0, COM: 0 };
        signals.forEach(s => { if (counts.hasOwnProperty(s.sigType)) counts[s.sigType]++; });

        const margin = parseFloat(marginPercent.value) || 0;

        const renderRow = (label, values, className) => `
            <tr class="${className}">
                <th colspan="2" style="text-align:right">${label}</th>
                ${['AI', 'AO', 'DI', 'DO', 'COM'].map(type => `<td>${values[type]}</td>`).join('')}
                <td colspan="2"></td>
            </tr>
        `;

        const marginValues = {};
        const totalValues = {};
        ['AI', 'AO', 'DI', 'DO', 'COM'].forEach(type => {
            marginValues[type] = Math.ceil(counts[type] * (margin / 100));
            totalValues[type] = counts[type] + marginValues[type];
        });

        tfoot.innerHTML = `
            <tr class="summary-header">
                <th colspan="2"></th>
                ${['AI', 'AO', 'DI', 'DO', 'COM'].map(type => `<th style="text-align:left; color:var(--text-secondary); font-size:10px;">${type}</th>`).join('')}
                <th colspan="2"></th>
            </tr>
            ${renderRow('SUBTOTAL', counts, 'summary-row-subtotal')}
            ${renderRow(`MARGEN (${margin}%)`, marginValues, 'summary-row-margin')}
            ${renderRow('TOTAL FINAL', totalValues, 'summary-row-total')}
        `;
    }

    function updateStats() {
        let ai = 0, ao = 0, di = 0, doo = 0, com = 0;
        signals.forEach(s => {
            if (s.sigType === 'AI') ai++;
            else if (s.sigType === 'AO') ao++;
            else if (s.sigType === 'DI') di++;
            else if (s.sigType === 'DO') doo++;
            else if (s.sigType === 'COM') com++;
        });
        statTotal.textContent = 'Total: ' + signals.length;
        statAI.textContent = 'AI: ' + ai;
        statAO.textContent = 'AO: ' + ao;
        statDI.textContent = 'DI: ' + di;
        statDO.textContent = 'DO: ' + doo;
        statCOM.textContent = 'COM: ' + com;
    }

    function renderAll() { 
        renderEquipmentList(); 
        renderSignalTable(); 
        updateStats(); 
        checkAccessControl();
    }

    // ----------------------------------------------------------
    // Access Control
    // ----------------------------------------------------------
    function checkAccessControl() {
        const restrictedElements = [
            btnExportExcel, btnExportCSV, btnAdd, 
            btnEditTemplates, btnManageTypes, btnClearAll
        ];

        // Also restrict "add signal" and "delete" buttons in equipment list
        const eqActionButtons = document.querySelectorAll('.eq-add-signal, .eq-delete');

        if (isLoggedIn) {
            restrictedElements.forEach(el => el.classList.remove('restricted'));
            eqActionButtons.forEach(el => el.classList.remove('restricted'));
            btnLogin.classList.add('logged-in');
            loginBtnText.textContent = 'Logout (jmg)';
            loginBtnIcon.textContent = '🔓';
        } else {
            restrictedElements.forEach(el => el.classList.add('restricted'));
            eqActionButtons.forEach(el => {
                // We want to visually lock them but still allow them to exist in DOM
                el.classList.add('restricted');
            });
            btnLogin.classList.remove('logged-in');
            loginBtnText.textContent = 'Login';
            loginBtnIcon.textContent = '👤';
        }
    }

    function handleLogin() {
        if (isLoggedIn) {
            isLoggedIn = false;
            checkAccessControl();
            return;
        }
        loginUserInput.value = '';
        loginPassInput.value = '';
        loginError.style.display = 'none';
        loginOverlay.classList.add('active');
        loginUserInput.focus();
    }

    function submitLogin() {
        if (loginUserInput.value === ADMIN_USER && loginPassInput.value === ADMIN_PASS) {
            isLoggedIn = true;
            loginOverlay.classList.remove('active');
            checkAccessControl();
        } else {
            loginError.style.display = 'block';
        }
    }

    // ----------------------------------------------------------
    // Core Actions
    // ----------------------------------------------------------
    function addEquipment() {
        const isBulk = bulkAddToggle.checked;
        const type = eqType.value;
        const desc = eqDesc.value.trim();
        const area = eqArea.value.trim();

        if (isBulk) {
            const start = eqTagStart.value.trim();
            const end = eqTagEnd.value.trim();
            if (!start || !end) {
                if (!start) eqTagStart.focus(); else eqTagEnd.focus();
                return;
            }
            const tags = expandTagRange(start, end);
            if (tags.length === 0) {
                alert('Rango de tags inválido. Asegúrate de que terminen en números y tengan el mismo prefijo.');
                return;
            }
            if (tags.length > 100) {
                if (!confirm(`Se van a añadir ${tags.length} equipos. ¿Continuar?`)) return;
            }
            tags.forEach(tag => createSingleEquipment(tag, desc, type, area));
            eqTagStart.value = ''; eqTagEnd.value = '';
        } else {
            const tag = eqTag.value.trim();
            if (!tag) { eqTag.focus(); return; }
            createSingleEquipment(tag, desc, type, area);
            eqTag.value = '';
        }

        eqDesc.value = ''; eqArea.value = '';
        (isBulk ? eqTagStart : eqTag).focus();
        renderAll();
    }

    function createSingleEquipment(tag, desc, type, area) {
        const eq = { id: nextEqId++, tag, desc, type, area };
        equipments.push(eq);

        const templates = SIGNAL_DB[type] || [];
        templates.forEach(t => {
            const sigTag = tag && t.suffix ? (tag + '-' + t.suffix) : (tag || t.suffix);
            signals.push({
                id: nextSigId++,
                eqId: eq.id,
                tag: sigTag,
                desc: t.desc,
                sigType: t.type,
                range: t.range,
                unit: t.unit,
                alarm: t.alarm || '0=alarma',
                notes: t.notes,
                instr: '', box: '', marsh: '', ctrl: '',
                rev: '0'
            });
        });
    }

    function expandTagRange(start, end) {
        const regex = /^(.*?)([0-9]+)$/;
        const m1 = start.match(regex);
        const m2 = end.match(regex);
        if (!m1 || !m2 || m1[1] !== m2[1]) return [];

        const prefix = m1[1];
        const sNum = parseInt(m1[2]);
        const eNum = parseInt(m2[2]);
        if (isNaN(sNum) || isNaN(eNum)) return [];

        const min = Math.min(sNum, eNum);
        const max = Math.max(sNum, eNum);
        const padLen = m1[2].length; // Use start padding length

        const results = [];
        for (let i = min; i <= max; i++) {
            const numStr = i.toString().padStart(padLen, '0');
            results.push(prefix + numStr);
        }
        return results;
    }

    function removeEquipment(eqId) {
        equipments = equipments.filter(e => e.id !== eqId);
        signals = signals.filter(s => s.eqId !== eqId);
        renderAll();
    }

    // ----------------------------------------------------------
    // Modal Management (Signal Edit)
    // ----------------------------------------------------------
    function openEditModal(sigId) {
        const sig = signals.find(s => s.id === sigId);
        if (!sig) return;
        editingSigId = sigId;
        modalTagInput.value = sig.tag;
        modalDescInput.value = sig.desc;
        modalSigTypeSelect.value = sig.sigType;
        modalRangeInput.value = sig.range;
        modalUnitInput.value = sig.unit;
        modalAlarmInput.value = sig.alarm;
        $('#modalInstr').value = sig.instr || '';
        $('#modalBox').value = sig.box || '';
        $('#modalMarsh').value = sig.marsh || '';
        $('#modalCtrl').value = sig.ctrl || '';
        modalNotesInput.value = sig.notes;
        modalRevInput.value = sig.rev;
        modalOverlay.classList.add('active');
    }

    function saveEditModal() {
        if (editingSigId === null) return;
        const sig = signals.find(s => s.id === editingSigId);
        if (!sig) return;
        sig.tag = modalTagInput.value.trim() || sig.tag;
        sig.desc = modalDescInput.value.trim();
        sig.sigType = modalSigTypeSelect.value;
        sig.range = modalRangeInput.value.trim();
        sig.unit = modalUnitInput.value.trim();
        sig.alarm = modalAlarmInput.value.trim();
        sig.instr = $('#modalInstr').value.trim();
        sig.box = $('#modalBox').value.trim();
        sig.marsh = $('#modalMarsh').value.trim();
        sig.ctrl = $('#modalCtrl').value.trim();
        sig.notes = modalNotesInput.value.trim();
        sig.rev = modalRevInput.value.trim();
        modalOverlay.classList.remove('active');
        editingSigId = null;
        renderAll();
    }

    // ----------------------------------------------------------
    // Modal Management (Add Custom Signal)
    // ----------------------------------------------------------
    function openAddModal(eqId) {
        const eq = equipments.find(e => e.id === eqId);
        if (!eq) return;
        addingForEqId = eqId;
        addTagInput.value = eq.tag + '-';
        addDescInput.value = '';
        addSigTypeSelect.value = 'DI';
        addRangeInput.value = 'ON/OFF';
        addUnitInput.value = '';
        addAlarmInput.value = '0=alarma';
        $('#addModalInstr').value = '';
        $('#addModalBox').value = '';
        $('#addModalMarsh').value = '';
        $('#addModalCtrl').value = '';
        addNotesInput.value = '';
        addRevInput.value = '0';
        addOverlay.classList.add('active');
        addTagInput.focus();
    }

    function saveAddModal() {
        if (addingForEqId === null) return;
        const tag = addTagInput.value.trim();
        if (!tag) { addTagInput.focus(); return; }
        signals.push({
            id: nextSigId++,
            eqId: addingForEqId,
            tag,
            desc: addDescInput.value.trim(),
            sigType: addSigTypeSelect.value,
            range: addRangeInput.value.trim(),
            unit: addUnitInput.value.trim(),
            alarm: addAlarmInput.value.trim(),
            instr: $('#addModalInstr').value.trim(),
            box: $('#addModalBox').value.trim(),
            marsh: $('#addModalMarsh').value.trim(),
            ctrl: $('#addModalCtrl').value.trim(),
            notes: addNotesInput.value.trim(),
            rev: addRevInput.value.trim() || '0'
        });
        addOverlay.classList.remove('active');
        addingForEqId = null;
        renderAll();
    }

    // ----------------------------------------------------------
    // Template Editor Management
    // ----------------------------------------------------------
    btnEditTemplates.addEventListener('click', () => {
        const type = eqType.value;
        templateTypeSelect.value = type;
        loadTemplateView(type);
        templateOverlay.classList.add('active');
    });

    templateTypeSelect.addEventListener('change', (e) => {
        loadTemplateView(e.target.value);
    });

    function loadTemplateView(type) {
        currentTemplateSignals = (SIGNAL_DB[type] || []).map(s => ({ ...s }));
        renderTemplateTable();
    }

    function renderTemplateTable() {
        templateTableBody.innerHTML = '';
        currentTemplateSignals.forEach((sig, idx) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><input type="text" class="tpl-suffix" value="${esc(sig.suffix)}" data-idx="${idx}"></td>
                <td><input type="text" class="tpl-desc" value="${esc(sig.desc)}" data-idx="${idx}"></td>
                <td>
                    <select class="tpl-type" data-idx="${idx}">
                        <option value="AI" ${sig.type === 'AI' ? 'selected' : ''}>AI</option>
                        <option value="AO" ${sig.type === 'AO' ? 'selected' : ''}>AO</option>
                        <option value="DI" ${sig.type === 'DI' ? 'selected' : ''}>DI</option>
                        <option value="DO" ${sig.type === 'DO' ? 'selected' : ''}>DO</option>
                    </select>
                </td>
                <td><input type="text" class="tpl-range" value="${esc(sig.range)}" data-idx="${idx}"></td>
                <td><input type="text" class="tpl-unit" value="${esc(sig.unit)}" data-idx="${idx}"></td>
                <td><input type="text" class="tpl-alarm" value="${esc(sig.alarm)}" data-idx="${idx}"></td>
                <td style="text-align:center">
                    <button class="btn-remove-template" data-idx="${idx}">✕</button>
                </td>
            `;
            templateTableBody.appendChild(tr);
        });

        // Event listeners for inputs to sync with state
        templateTableBody.querySelectorAll('input, select').forEach(el => {
            el.addEventListener('change', () => {
                const idx = parseInt(el.dataset.idx);
                const field = el.classList.contains('tpl-suffix') ? 'suffix' :
                    el.classList.contains('tpl-desc') ? 'desc' :
                        el.classList.contains('tpl-type') ? 'type' :
                            el.classList.contains('tpl-range') ? 'range' :
                                el.classList.contains('tpl-unit') ? 'unit' : 'alarm';
                currentTemplateSignals[idx][field] = el.value;
            });
        });

        templateTableBody.querySelectorAll('.btn-remove-template').forEach(btn => {
            btn.addEventListener('click', () => {
                const idx = parseInt(btn.dataset.idx);
                currentTemplateSignals.splice(idx, 1);
                renderTemplateTable();
            });
        });
    }

    btnAddTemplateRow.addEventListener('click', () => {
        currentTemplateSignals.push({ suffix: '', desc: '', type: 'DI', range: 'ON/OFF', unit: '', alarm: '', notes: '' });
        renderTemplateTable();
    });

    templateSave.addEventListener('click', () => {
        const type = templateTypeSelect.value;
        SIGNAL_DB[type] = currentTemplateSignals.filter(s => s.suffix.trim() !== '');
        templateOverlay.classList.remove('active');
    });

    templateCancel.addEventListener('click', () => templateOverlay.classList.remove('active'));
    templateClose.addEventListener('click', () => templateOverlay.classList.remove('active'));

    // ----------------------------------------------------------
    // Project Save/Load & Export
    // ----------------------------------------------------------
    function saveProject() {
        const data = { version: '1.2', equipments, signals, templateDb: SIGNAL_DB, types: EQUIPMENT_TYPES, nextEqId, nextSigId };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'signal-list-project.json';
        a.click();
    }

    function loadProject(file) {
        const reader = new FileReader();
        reader.onload = e => {
            try {
                const data = JSON.parse(e.target.result);
                equipments = data.equipments || [];
                signals = data.signals || [];
                if (data.templateDb) SIGNAL_DB = data.templateDb;
                if (data.types) EQUIPMENT_TYPES = data.types;
                nextEqId = data.nextEqId || (equipments.length + 1);
                nextSigId = data.nextSigId || (signals.length + 1);
                renderTypeDropdowns();
                renderAll();
            } catch (err) { alert('Error: ' + err.message); }
        };
        reader.readAsText(file);
    }

    const EXCEL_CSV_HEADERS = [
        'Equipo Tag', 'Equipo Desc', 'Equipo Tipo', 'Equipo Area',
        'Señal Tag', 'Señal Desc', 'Señal Tipo', 'Rango', 'Unidades', 'Alarma',
        'Instrumento', 'Caja', 'Marshalling', 'Control',
        'Notas', 'Revisión'
    ];

    function getSignalsData() {
        return signals.map(s => {
            const eq = equipments.find(e => e.id === s.eqId) || {};
            return [
                eq.tag || '', eq.desc || '', eq.type || '', eq.area || '',
                s.tag, s.desc, s.sigType, s.range, s.unit, s.alarm,
                s.instr || '', s.box || '', s.marsh || '', s.ctrl || '',
                s.notes, s.rev
            ];
        });
    }

    function exportExcel() {
        if (signals.length === 0) return;
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet([EXCEL_CSV_HEADERS, ...getSignalsData()]);
        XLSX.utils.book_append_sheet(wb, ws, 'Lista de Señales');
        XLSX.writeFile(wb, 'lista-de-senales.xlsx');
    }

    function exportCSV() {
        if (signals.length === 0) return;
        const rows = [EXCEL_CSV_HEADERS, ...getSignalsData()];
        const csvContent = rows.map(r => r.map(c => `"${(c || '').toString().replace(/"/g, '""')}"`).join(',')).join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.setAttribute("download", "lista-de-senales.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    function importExcel(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const sheet = workbook.Sheets[workbook.SheetNames[0]];
                const json = XLSX.utils.sheet_to_json(sheet, { header: 1 });
                processImportData(json);
            } catch (err) { alert('Error al leer Excel.'); }
        };
        reader.readAsArrayBuffer(file);
    }

    function importCSV(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const text = e.target.result;
                const rows = text.split('\n').filter(r => r.trim()).map(r => {
                    const matches = r.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g);
                    return matches ? matches.map(m => m.replace(/^"|"$/g, '').replace(/""/g, '"')) : [];
                });
                processImportData(rows);
            } catch (err) { alert('Error al leer CSV.'); }
        };
        reader.readAsText(file);
    }

    function processImportData(json) {
        if (json.length < 2) return;
        const headers = json[0];
        if (headers.length < 8) { alert('Formato inválido.'); return; }

        for (let i = 1; i < json.length; i++) {
            const row = json[i];
            if (!row || row.length === 0) continue;

            const eqTagVal = (row[0] || '').toString().trim();
            const eqDescVal = (row[1] || '').toString().trim();
            const eqTypeVal = (row[2] || '').toString().trim();
            const eqAreaVal = (row[3] || '').toString().trim();

            const sigTagVal = (row[4] || '').toString().trim();
            const sigDescVal = (row[5] || '').toString().trim();
            const sigTypeVal = (row[6] || '').toString().trim();
            const sigRangeVal = (row[7] || '').toString().trim();
            const sigUnitVal = (row[8] || '').toString().trim();
            const sigAlarmVal = (row[9] || '').toString().trim();

            const sigInstrVal = (row[10] || '').toString().trim();
            const sigBoxVal = (row[11] || '').toString().trim();
            const sigMarshVal = (row[12] || '').toString().trim();
            const sigCtrlVal = (row[13] || '').toString().trim();
            const sigNotesVal = (row[14] || '').toString().trim();
            const sigRevVal = (row[15] || '').toString().trim();

            if (!eqTagVal || !sigTagVal) continue;

            let eq = equipments.find(e => e.tag.toUpperCase() === eqTagVal.toUpperCase());
            if (!eq) {
                eq = { id: nextEqId++, tag: eqTagVal, desc: eqDescVal, type: eqTypeVal || 'Presión', area: eqAreaVal };
                equipments.push(eq);
            }

            const exists = signals.find(s => s.eqId === eq.id && s.tag.toUpperCase() === sigTagVal.toUpperCase());
            if (!exists) {
                signals.push({
                    id: nextSigId++,
                    eqId: eq.id,
                    tag: sigTagVal,
                    desc: sigDescVal,
                    sigType: sigTypeVal || 'DI',
                    range: sigRangeVal,
                    unit: sigUnitVal,
                    alarm: sigAlarmVal || '0=alarma',
                    instr: sigInstrVal,
                    box: sigBoxVal,
                    marsh: sigMarshVal,
                    ctrl: sigCtrlVal,
                    notes: sigNotesVal,
                    rev: sigRevVal || '0'
                });
            }
        }
        renderAll();
        alert('Importación completada.');
    }


    // ----------------------------------------------------------
    // Dynamic Type Management
    // ----------------------------------------------------------
    function renderTypeDropdowns() {
        const optionsHTML = EQUIPMENT_TYPES.map(t => `<option value="${t.name}">${t.icon} ${t.name}</option>`).join('');
        eqType.innerHTML = optionsHTML;
        templateTypeSelect.innerHTML = optionsHTML;
    }

    function renderManageTypesList() {
        typesListContainer.innerHTML = '';
        EQUIPMENT_TYPES.forEach((t, idx) => {
            const div = document.createElement('div');
            div.className = 'manage-type-item';
            div.innerHTML = `
                <div class="type-preview" style="background:${t.color}"></div>
                <div class="type-name">${t.icon} ${t.name}</div>
                <button class="btn-delete-type" data-idx="${idx}">🗑</button>
            `;
            typesListContainer.appendChild(div);
        });
        typesListContainer.querySelectorAll('.btn-delete-type').forEach(btn => {
            btn.addEventListener('click', () => {
                const idx = parseInt(btn.dataset.idx);
                const typeName = EQUIPMENT_TYPES[idx].name;
                if (confirm(`¿Eliminar el tipo "${typeName}"? Esto no borrará los equipos ya creados.`)) {
                    EQUIPMENT_TYPES.splice(idx, 1);
                    renderTypeDropdowns();
                    renderManageTypesList();
                }
            });
        });
    }

    btnManageTypes.addEventListener('click', () => {
        renderManageTypesList();
        manageOverlay.classList.add('active');
    });

    btnAddNewType.addEventListener('click', () => {
        const name = newTypeName.value.trim();
        const icon = newTypeIcon.value.trim() || '📦';
        const color = newTypeColor.value;
        if (!name) { newTypeName.focus(); return; }
        if (EQUIPMENT_TYPES.some(t => t.name.toLowerCase() === name.toLowerCase())) {
            alert('Este tipo ya existe.');
            return;
        }
        EQUIPMENT_TYPES.push({ name, icon, color });
        if (!SIGNAL_DB[name]) SIGNAL_DB[name] = [];
        newTypeName.value = ''; newTypeIcon.value = '';
        renderTypeDropdowns();
        renderManageTypesList();
    });

    const closeManage = () => manageOverlay.classList.remove('active');
    manageClose.addEventListener('click', closeManage);
    manageCloseBtn.addEventListener('click', closeManage);

    btnLoadIndustrial.addEventListener('click', () => {
        const type = templateTypeSelect.value;
        const defaults = INDUSTRIAL_DEFAULTS[type];
        if (defaults) {
            currentTemplateSignals = JSON.parse(JSON.stringify(defaults));
            renderTemplateTable();
        } else {
            alert('No hay típicos industriales definidos para este tipo.');
        }
    });

    // ----------------------------------------------------------
    // Init & Base utils
    // ----------------------------------------------------------
    function esc(s) {
        if (!s) return '';
        const d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    btnAdd.addEventListener('click', addEquipment);
    [eqTag, eqTagStart, eqTagEnd, eqDesc, eqArea].forEach(el => {
        el.addEventListener('keydown', e => { if (e.key === 'Enter') addEquipment(); });
    });
    btnNew.addEventListener('click', () => {
        if (signals.length > 0 && confirm('¿Nuevo proyecto?')) {
            equipments = []; signals = []; nextEqId = 1; nextSigId = 1; renderAll();
        }
    });
    btnSave.addEventListener('click', saveProject);
    bulkAddToggle.addEventListener('change', () => {
        const isBulk = bulkAddToggle.checked;
        singleTagContainer.style.display = isBulk ? 'none' : 'block';
        bulkTagContainer.style.display = isBulk ? 'block' : 'none';

        if (isBulk) sidebarEl.classList.add('sidebar-expanded');
        else sidebarEl.classList.remove('sidebar-expanded');

        (isBulk ? eqTagStart : eqTag).focus();
    });
    marginPercent.addEventListener('input', renderAll);
    fileLoad.addEventListener('change', e => { if (e.target.files[0]) loadProject(e.target.files[0]); });
    btnExportExcel.addEventListener('click', exportExcel);
    btnExportCSV.addEventListener('click', exportCSV);
    btnImportExcel.addEventListener('click', () => excelLoad.click());
    btnImportCSV.addEventListener('click', () => csvLoad.click());
    excelLoad.addEventListener('change', e => { if (e.target.files[0]) importExcel(e.target.files[0]); });
    csvLoad.addEventListener('change', e => { if (e.target.files[0]) importCSV(e.target.files[0]); });
    btnClearAll.addEventListener('click', () => {
        if (confirm('¿Borrar todo?')) { equipments = []; signals = []; renderAll(); }
    });

    modalCancel.addEventListener('click', () => modalOverlay.classList.remove('active'));
    modalClose.addEventListener('click', () => modalOverlay.classList.remove('active'));
    modalSave.addEventListener('click', saveEditModal);

    addCancel.addEventListener('click', () => addOverlay.classList.remove('active'));
    addClose.addEventListener('click', () => addOverlay.classList.remove('active'));
    addSave.addEventListener('click', saveAddModal);

    btnLogin.addEventListener('click', handleLogin);
    loginClose.addEventListener('click', () => loginOverlay.classList.remove('active'));
    loginCancel.addEventListener('click', () => loginOverlay.classList.remove('active'));
    loginSubmit.addEventListener('click', submitLogin);
    loginPassInput.addEventListener('keydown', e => { if (e.key === 'Enter') submitLogin(); });

    renderTypeDropdowns();
    renderAll();

})();
