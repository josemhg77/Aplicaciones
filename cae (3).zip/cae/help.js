// ═══════════════════════════════════════════════════════════════════════════════
// CAE 2026 — HELP MODULE: Modal + PDF generator (white background, with images)
// ═══════════════════════════════════════════════════════════════════════════════

function initHelpModal() {
    var helpModal    = document.getElementById('helpModal');
    var btnHelp      = document.getElementById('btnHelp');
    var btnCloseHelp = document.getElementById('btnCloseHelp');
    var btnPrev      = document.getElementById('btnHelpPrev');
    var btnNext      = document.getElementById('btnHelpNext');
    var btnPDFHelp   = document.getElementById('btnDownloadHelpPDF');
    var tabs         = document.querySelectorAll('.help-tab');
    var steps        = document.querySelectorAll('.help-step');
    var dots         = document.querySelectorAll('.help-dot');
    var counter      = document.getElementById('helpStepCounter');

    if (!helpModal || !btnHelp) return;

    var TOTAL_STEPS = 5;
    var currentStep = 0;

    function goToStep(n) {
        currentStep = Math.max(0, Math.min(TOTAL_STEPS - 1, n));
        steps.forEach(function(s, i) { s.classList.toggle('active', i === currentStep); });
        tabs.forEach(function(t, i)  { t.classList.toggle('active', i === currentStep); });
        dots.forEach(function(d, i)  { d.classList.toggle('active', i === currentStep); });
        if (counter) counter.textContent = 'Paso ' + (currentStep + 1) + ' de ' + TOTAL_STEPS;
        if (btnPrev) btnPrev.disabled = (currentStep === 0);
        if (btnNext) {
            btnNext.disabled = (currentStep === TOTAL_STEPS - 1);
            btnNext.textContent = (currentStep === TOTAL_STEPS - 1) ? 'Fin ✓' : 'Siguiente →';
        }
    }

    function openHelp()  { helpModal.classList.add('active');    goToStep(0); document.body.style.overflow = 'hidden'; }
    function closeHelp() { helpModal.classList.remove('active'); document.body.style.overflow = ''; }

    btnHelp.addEventListener('click', openHelp);
    if (btnCloseHelp) btnCloseHelp.addEventListener('click', closeHelp);
    if (btnPrev)      btnPrev.addEventListener('click', function() { goToStep(currentStep - 1); });
    if (btnNext)      btnNext.addEventListener('click', function() { goToStep(currentStep + 1); });
    if (btnPDFHelp)   btnPDFHelp.addEventListener('click', generateHelpPDF);

    tabs.forEach(function(tab, i) { tab.addEventListener('click', function() { goToStep(i); }); });
    dots.forEach(function(dot, i) { dot.addEventListener('click', function() { goToStep(i); }); });
    helpModal.addEventListener('click', function(e) { if (e.target === helpModal) closeHelp(); });
    document.addEventListener('keydown', function(e) {
        if (!helpModal.classList.contains('active')) return;
        if (e.key === 'Escape')     closeHelp();
        if (e.key === 'ArrowRight') goToStep(currentStep + 1);
        if (e.key === 'ArrowLeft')  goToStep(currentStep - 1);
    });
}

// ═══════════════════════════════════════════════════════════════════════════════
// Carga de imágenes para el PDF (fetch → base64)
// ═══════════════════════════════════════════════════════════════════════════════
function loadImgAsBase64(path) {
    return new Promise(function(resolve) {
        var img = new Image();
        img.onload = function() {
            try {
                var canvas = document.createElement('canvas');
                canvas.width  = img.width;
                canvas.height = img.height;
                canvas.getContext('2d').drawImage(img, 0, 0);
                resolve({ data: canvas.toDataURL('image/png'), w: img.width, h: img.height });
            } catch (e) {
                console.warn('Error procesando imagen para PDF (' + path + '): ', e.message);
                resolve(null); // Fallback sin imagen en caso de error de CORS (file:// protocol)
            }
        };
        img.onerror = function() { resolve(null); };
        // Cache-bust para file://
        img.src = path + '?cb=' + Date.now();
    });
}

// ═══════════════════════════════════════════════════════════════════════════════
// GENERATE HELP PDF
// ═══════════════════════════════════════════════════════════════════════════════
function generateHelpPDF() {
    var jsPDFLib = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
    if (!jsPDFLib) { alert('Error: La librería jsPDF no está disponible.'); return; }

    var btn = document.getElementById('btnDownloadHelpPDF');
    if (btn) { btn.textContent = '⏳ Generando PDF...'; btn.disabled = true; }

    // Carga paralela de las 4 imágenes
    var imgs = ['help_img_overview.png','help_img_toolbar.png','help_img_sidebar.png','help_img_users.png'];
    Promise.all(imgs.map(loadImgAsBase64)).then(function(loaded) {
        try {
            var imgOverview = loaded[0];
            var imgToolbar  = loaded[1];
            var imgSidebar  = loaded[2];
            var imgUsers    = loaded[3];

            _buildPDF(jsPDFLib, imgOverview, imgToolbar, imgSidebar, imgUsers);
        } catch (e) {
            console.error('Error generando PDF:', e);
            alert('Hubo un error al generar el PDF: ' + e.message);
        } finally {
            if (btn) { btn.textContent = '⬇ Descargar PDF'; btn.disabled = false; }
        }
    });
}

function _buildPDF(jsPDFLib, imgOverview, imgToolbar, imgSidebar, imgUsers) {
    var doc = new jsPDFLib({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    var W = 210, H = 297, margin = 18, contentW = 174;

    var C = {
        headerBg:   [0,  82, 147],
        headerText: [255,255,255],
        accent:     [0, 122, 204],
        accentLight:[220, 235, 248],
        orange:     [200, 100,   0],
        orangeLight:[255, 243, 220],
        textMain:   [30,  30,  30],
        textSub:    [90,  90,  90],
        textField:  [0,   82, 147],
        textEx:     [180,  80,  0],
        thBg:       [230, 238, 248],
        rowOdd:     [255, 255, 255],
        rowEven:    [243, 248, 255],
        rowBorder:  [200, 215, 230],
        tableBorder:[160, 190, 220],
        pageBg:     [255, 255, 255],
        footerBg:   [240, 244, 250],
        divider:    [180, 210, 235],
    };

    // ── Helpers ──────────────────────────────────────────────────────────────
    function newPage(title) {
        doc.addPage();
        doc.setFillColor(...C.pageBg); doc.rect(0,0,W,H,'F');
        doc.setFillColor(...C.headerBg); doc.rect(0,0,W,16,'F');
        doc.setDrawColor(...C.accent); doc.setLineWidth(0.3); doc.line(0,16,W,16);
        doc.setFontSize(8.5); doc.setFont('helvetica','bold'); doc.setTextColor(...C.headerText);
        doc.text('CAE 2026  |  Guia de Uso', margin, 10.5);
        doc.setFont('helvetica','normal');
        doc.text(title, W-margin, 10.5, {align:'right'});
        doc.setFillColor(...C.footerBg); doc.rect(0,H-11,W,11,'F');
        doc.setDrawColor(...C.divider); doc.setLineWidth(0.3); doc.line(0,H-11,W,H-11);
        doc.setFontSize(7.5); doc.setTextColor(...C.textSub);
        doc.text('CAE 2026 v2.1.5  —  Guia paso a paso', margin, H-4);
        doc.text('Pagina ' + doc.internal.getNumberOfPages(), W-margin, H-4, {align:'right'});
    }

    function badge(label, x, y) {
        doc.setFillColor(...C.accent); doc.roundedRect(x,y-5,30,7,2,2,'F');
        doc.setFontSize(8); doc.setFont('helvetica','bold'); doc.setTextColor(...C.headerText);
        doc.text(label, x+15, y, {align:'center'}); return y+5;
    }

    function h1(title, y) {
        doc.setFontSize(15); doc.setFont('helvetica','bold'); doc.setTextColor(...C.headerBg);
        doc.text(title, margin, y);
        doc.setDrawColor(...C.accent); doc.setLineWidth(0.6); doc.line(margin,y+1.5,W-margin,y+1.5);
        return y+9;
    }

    function h2(title, y, col) {
        var c = col || C.accent;
        doc.setFontSize(11); doc.setFont('helvetica','bold'); doc.setTextColor(...c);
        doc.text(title, margin, y);
        doc.setDrawColor(...c); doc.setLineWidth(0.3); doc.line(margin,y+1,W-margin,y+1);
        return y+7;
    }

    function intro(text, y, w) {
        doc.setFontSize(9.5); doc.setFont('helvetica','normal'); doc.setTextColor(...C.textSub);
        var lines = doc.splitTextToSize(text, w||contentW);
        doc.text(lines, margin, y); return y + lines.length*5 + 2;
    }

    function table(rows, y, hasEx) {
        var colF=50, colD=hasEx?90:(contentW-50), defH=7.5;
        doc.setFillColor(...C.thBg); doc.rect(margin,y,contentW,defH,'F');
        doc.setDrawColor(...C.tableBorder); doc.setLineWidth(0.3); doc.rect(margin,y,contentW,defH,'S');
        doc.setFontSize(7); doc.setFont('helvetica','bold'); doc.setTextColor(...C.textField);
        doc.text('CAMPO', margin+3, y+5);
        doc.text('DESCRIPCION', margin+colF+3, y+5);
        if (hasEx) doc.text('EJEMPLO', margin+colF+colD+2, y+5);
        doc.line(margin+colF,y,margin+colF,y+defH);
        if (hasEx) doc.line(margin+colF+colD,y,margin+colF+colD,y+defH);
        var sy=y; y+=defH;
        rows.forEach(function(r,i){
            doc.setFontSize(8); doc.setFont('helvetica','normal');
            var dl=doc.splitTextToSize(r[1], colD-5);
            doc.setFont('helvetica','bold');
            var cl=doc.splitTextToSize(r[0], colF-5);
            
            var reqLines = Math.max(dl.length, cl.length);
            var el = null;
            if (hasEx && r[2]) {
                el = doc.splitTextToSize(r[2], contentW - colF - colD - 5);
                reqLines = Math.max(reqLines, el.length);
            }
            
            var rowH = Math.max(defH, reqLines * 3.5 + 4);

            doc.setFillColor(...(i%2===0?C.rowOdd:C.rowEven));
            doc.rect(margin,y,contentW,rowH,'F');
            doc.setFontSize(8); doc.setFont('helvetica','bold'); doc.setTextColor(...C.textField);
            doc.text(cl, margin+3, y+5);
            doc.setFont('helvetica','normal'); doc.setTextColor(...C.textMain);
            doc.text(dl, margin+colF+3, y+5);
            if (hasEx && el){ doc.setFont('helvetica','bold'); doc.setTextColor(...C.textEx); doc.text(el, margin+colF+colD+2, y+5); }
            
            doc.setDrawColor(...C.rowBorder); doc.setLineWidth(0.2); doc.line(margin,y+rowH,margin+contentW,y+rowH);
            doc.line(margin+colF,y,margin+colF,y+rowH);
            if (hasEx) doc.line(margin+colF+colD,y,margin+colF+colD,y+rowH);
            y+=rowH;
        });
        doc.setDrawColor(...C.tableBorder); doc.setLineWidth(0.5); doc.rect(margin,sy,contentW,y-sy,'S');
        return y+3;
    }

    function tip(text, y, warn) {
        var col=warn?C.orange:C.accent, bg=warn?C.orangeLight:C.accentLight;
        doc.setFontSize(8); doc.setFont('helvetica','normal');
        var tl=doc.splitTextToSize(text,contentW-16);
        var boxH = Math.max(10, tl.length * 3.5 + 5);

        doc.setFillColor(...bg); doc.roundedRect(margin,y,contentW,boxH,2,2,'F');
        doc.setDrawColor(...col); doc.setLineWidth(0.5); doc.roundedRect(margin,y,contentW,boxH,2,2,'S');
        doc.setFillColor(...col); doc.circle(margin+5.5,y+5,2.8,'F');
        doc.setFontSize(7); doc.setFont('helvetica','bold'); doc.setTextColor(255,255,255);
        doc.text(warn?'!':'i',margin+5.5,y+6.2,{align:'center'});
        doc.setTextColor(...col); doc.setFont('helvetica','normal'); doc.setFontSize(8);
        doc.text(tl,margin+12,y+6.5);
        return y+boxH+3;
    }

    // Insertar imagen con proporción contenida en un rectángulo maxW×maxH
    function addImg(imgData, x, y, maxW, maxH) {
        if (!imgData) return y + 5;
        var ratio = imgData.w / imgData.h;
        var rW = maxW, rH = maxW / ratio;
        if (rH > maxH) { rH = maxH; rW = maxH * ratio; }
        var xOff = x + (maxW - rW) / 2;
        doc.addImage(imgData.data, 'PNG', xOff, y, rW, rH);
        // Marco
        doc.setDrawColor(...C.divider); doc.setLineWidth(0.3);
        doc.rect(xOff, y, rW, rH, 'S');
        return y + rH + 2;
    }

    // Caja de imagen con título de pie
    function imgBox(imgData, x, y, maxW, maxH, caption) {
        var nextY = addImg(imgData, x, y, maxW, maxH);
        if (caption) {
            doc.setFontSize(7.5); doc.setFont('helvetica','italic'); doc.setTextColor(...C.textSub);
            doc.text(caption, x + maxW/2, nextY + 2, {align:'center'});
            nextY += 6;
        }
        return nextY;
    }

    // Botón de grupo (tooltip-style box)
    function groupBox(label, btns, x, y, boxW) {
        // Caja grupo
        doc.setFillColor(...C.accentLight); doc.roundedRect(x,y,boxW,28,2,2,'F');
        doc.setDrawColor(...C.accent); doc.setLineWidth(0.3); doc.roundedRect(x,y,boxW,28,2,2,'S');
        // Etiqueta grupo
        doc.setFontSize(7); doc.setFont('helvetica','bold'); doc.setTextColor(...C.accent);
        doc.text(label, x+boxW/2, y+5, {align:'center'});
        // Botones
        var bx = x + 3, bw = (boxW-6)/btns.length - 1;
        btns.forEach(function(b, i) {
            var col = b.col || C.headerBg;
            doc.setFillColor(...col); doc.roundedRect(bx,y+8,bw,10,1.5,1.5,'F');
            doc.setFontSize(6.5); doc.setFont('helvetica','bold'); doc.setTextColor(255,255,255);
            var lbl = doc.splitTextToSize(b.label, bw-2);
            doc.text(lbl[0]||b.label, bx+bw/2, y+14.5, {align:'center'});
            bx += bw + 1;
        });
        return y+28;
    }

    // ── PORTADA ───────────────────────────────────────────────────────────────
    doc.setFillColor(...C.pageBg); doc.rect(0,0,W,H,'F');
    doc.setFillColor(...C.headerBg); doc.rect(0,0,W,70,'F');
    doc.setFillColor(...C.accent); doc.rect(0,68,W,4,'F');
    doc.setFontSize(38); doc.setFont('helvetica','bold'); doc.setTextColor(255,255,255);
    doc.text('CAE 2026', W/2, 32, {align:'center'});
    doc.setFontSize(13); doc.setFont('helvetica','normal'); doc.setTextColor(180,210,240);
    doc.text('Loop Sheet Generator', W/2, 44, {align:'center'});
    doc.setFontSize(10); doc.setTextColor(140,175,210);
    doc.text('v2.1.5  —  11/03/2026', W/2, 53, {align:'center'});
    doc.setFontSize(20); doc.setFont('helvetica','bold'); doc.setTextColor(...C.headerBg);
    doc.text('Guia de Uso Paso a Paso', W/2, 90, {align:'center'});
    doc.setFontSize(11); doc.setFont('helvetica','normal'); doc.setTextColor(...C.textSub);
    doc.text('Interfaz, gestion de usuarios y hojas, y creacion completa de un lazo', W/2, 100, {align:'center'});
    doc.setDrawColor(...C.divider); doc.setLineWidth(0.6); doc.line(margin,108,W-margin,108);

    var toc = [
        ['Intro 1','Vision General de la Interfaz',           '2'],
        ['Intro 2','Barra Superior: todos los botones',       '3'],
        ['Intro 3','Gestion de Hojas, Lazos y Usuarios',      '4'],
        ['Paso 1', 'Configurar el Instrumento',                '5'],
        ['Paso 2', 'Configurar la Caja de Conexiones (JB)',   '6'],
        ['Paso 3', 'Configurar el Armario Marshalling',       '7'],
        ['Paso 4', 'Configurar el Control Detallado (PLC)',   '8'],
        ['Paso 5', 'Resultado, Gestion de Hojas y Exportacion','9'],
    ];
    var ty=116;
    doc.setFontSize(12); doc.setFont('helvetica','bold'); doc.setTextColor(...C.headerBg);
    doc.text('Contenido', margin, ty); ty+=9;
    toc.forEach(function(item,i){
        var bg=(i%2===0)?C.rowOdd:C.accentLight;
        doc.setFillColor(...bg); doc.roundedRect(margin,ty-3.5,contentW,9,1,1,'F');
        doc.setDrawColor(...C.divider); doc.setLineWidth(0.2); doc.roundedRect(margin,ty-3.5,contentW,9,1,1,'S');
        doc.setFillColor(...(i<3?C.orange:C.accent));
        doc.roundedRect(margin+2,ty-2.5,22,7,1.5,1.5,'F');
        doc.setFontSize(7.5); doc.setFont('helvetica','bold'); doc.setTextColor(255,255,255);
        doc.text(item[0],margin+13,ty+2.5,{align:'center'});
        doc.setFont('helvetica','normal'); doc.setTextColor(...C.textMain); doc.setFontSize(9.5);
        doc.text(item[1],margin+28,ty+2.5);
        doc.setTextColor(...C.textSub); doc.setFontSize(8.5);
        doc.text(item[2],W-margin-4,ty+2.5,{align:'right'});
        ty+=11;
    });
    doc.setFillColor(...C.footerBg); doc.rect(0,H-14,W,14,'F');
    doc.setDrawColor(...C.divider); doc.line(0,H-14,W,H-14);
    doc.setFontSize(8); doc.setFont('helvetica','normal'); doc.setTextColor(...C.textSub);
    doc.text('Generado automaticamente por CAE 2026', W/2, H-5, {align:'center'});

    // ══════════════════════════════════════════════════════════════════════════
    // INTRO 1 — VISION GENERAL DE LA INTERFAZ
    // ══════════════════════════════════════════════════════════════════════════
    newPage('Intro 1 — Vision General');
    var y=24;
    y = badge('INTRO 1', margin, y) + 3;
    y = h1('Vision General de la Interfaz', y);
    y = intro('CAE 2026 es una aplicacion web diseñada para crear y gestionar diagramas de lazos de instrumentacion (Loop Sheets) de forma rapida y profesional. La interfaz se divide en cuatro zonas principales:', y);

    // Imagen overview
    if (imgOverview) {
        y = imgBox(imgOverview, margin, y+2, contentW, 72, 'Fig. 1 — Interfaz completa de CAE 2026');
        y += 2;
    } else { y += 5; }

    y = h2('Zonas principales de la aplicacion', y, C.accent);
    var zones = [
        ['1. Barra Superior (Toolbar)', 'Contiene todos los grupos de botones de accion: Proyecto, Lazos, Numeracion, Exportacion, Vista, Usuario y Ayuda.'],
        ['2. Panel Lateral Izquierdo',  'Datos del proyecto, gestion de hojas (Anterior/Siguiente, Anadir, Borrar) y selector de lazos 1-12.'],
        ['3. Barra de Parametros',      'Inputs de configuracion del lazo activo: Instrumento, Caja (JB), Marshalling y Control (PLC).'],
        ['4. Canvas / Diagrama',        'Vista grafica del loop sheet generado en tiempo real a partir de los parametros introducidos.'],
    ];
    y = table(zones, y, false);
    y = tip('Todos los cambios se guardan automaticamente en el navegador. Al reabrir la aplicacion se recupera el ultimo estado sin necesidad de guardar manualmente.', y+1);

    // ══════════════════════════════════════════════════════════════════════════
    // INTRO 2 — BARRA SUPERIOR: TODOS LOS BOTONES
    // ══════════════════════════════════════════════════════════════════════════
    newPage('Intro 2 — Barra Superior');
    y=24;
    y = badge('INTRO 2', margin, y) + 3;
    y = h1('Barra Superior: todos los botones', y);
    y = intro('La barra superior agrupa todas las acciones principales en grupos etiquetados. Cada grupo se describe a continuacion.', y);

    // Imagen toolbar
    if (imgToolbar) {
        y = imgBox(imgToolbar, margin, y+2, contentW, 38, 'Fig. 2 — Barra superior con todos los grupos de botones');
        y += 3;
    } else { y += 5; }

    var toolbarData = [
        // [Grupo, Boton, Descripcion]
        ['PROYECTO',    'Nuevo',        'Crea un proyecto en blanco. Borra todas las hojas y lazos actuales (pide confirmacion).'],
        ['PROYECTO',    'Guardar',      'Descarga el proyecto completo como archivo .json. Guarda hojas, lazos, colores y nombre del proyecto.'],
        ['PROYECTO',    'Cargar',       'Abre un archivo .json previamente guardado y restaura todo el proyecto.'],
        ['LAZOS',       'Duplicar',     '[Login] Requiere login. Copia todos los datos del lazo activo al siguiente hueco libre de la hoja actual.'],
        ['LAZOS',       'Borrar',       '[Login] Requiere login. Limpia completamente todos los datos del lazo activo dejandolo en blanco.'],
        ['NUMERACION',  'Por Tag / Num','Cambia el modo de numeracion de bornas: por Tag del instrumento o numeracion correlativa.'],
        ['EXPORTACION', 'PDF',          '[Login] Requiere login. Genera un PDF tecnico multi-pagina con todos los lazos de todas las hojas.'],
        ['EXPORTACION', 'DXF',          '[Login] Requiere login. Exporta los diagramas en formato DXF compatible con AutoCAD y BricsCAD.'],
        ['VISTA',       'Diagrama',     'Muestra el canvas con el diagrama de lazos del lazo activo (vista predeterminada).'],
        ['VISTA',       'Lista Cables', 'Muestra la tabla resumen de todos los cables del proyecto con seccion, longitud y tipo.'],
        ['VISTA',       'Cajas',        'Muestra el diagrama de distribucion de prensaestopas en cajas de conexion y armarios marshalling.'],
        ['USUARIO',     'Acceder',      'Abre el dialogo de login para introducir usuario y contrasena. Una vez autenticado el boton pasa a mostrar "Salir (usuario)".'],
        ['USUARIO',     'Salir',        'Cierra la sesion del usuario activo. Los botones restringidos vuelven a quedar bloqueados.'],
        ['AYUDA',       '? Ayuda',      'Abre esta guia paso a paso interactiva. No requiere login. Disponible en todo momento.'],
    ];
    y = table(toolbarData, y, false);
    y = tip('Los botones marcados con [Login] requieren iniciar sesion. Aparecen atenuados y no son clicables hasta que el usuario se autentica correctamente.', y+1);

    // ══════════════════════════════════════════════════════════════════════════
    // INTRO 3 — GESTION DE HOJAS, LAZOS Y USUARIOS
    // ══════════════════════════════════════════════════════════════════════════
    newPage('Intro 3 — Gestion de Hojas, Lazos y Usuarios');
    y=24;
    y = badge('INTRO 3', margin, y) + 3;
    y = h1('Gestion de Hojas, Lazos y Usuarios', y);

    // Dos columnas: sidebar izq, users der
    var colW = (contentW - 8) / 2;

    // Imagen sidebar
    var yLeft = y, yRight = y;
    if (imgSidebar) {
        var afterSidebar = addImg(imgSidebar, margin, y, colW, 90);
        doc.setFontSize(7.5); doc.setFont('helvetica','italic'); doc.setTextColor(...C.textSub);
        doc.text('Fig. 3 — Panel lateral: gestion de hojas y lazos', margin+colW/2, afterSidebar+1.5, {align:'center'});
        yLeft = afterSidebar + 5;
    }
    if (imgUsers) {
        var xR = margin + colW + 8;
        var afterUsers = addImg(imgUsers, xR, y, colW, 60);
        doc.setFontSize(7.5); doc.setFont('helvetica','italic'); doc.setTextColor(...C.textSub);
        doc.text('Fig. 4 — Dialogo de acceso restringido', xR+colW/2, afterUsers+1.5, {align:'center'});
        yRight = afterUsers + 5;
    }
    y = Math.max(yLeft, yRight) + 2;

    y = h2('Panel Lateral — Gestion de Hojas', y, C.accent);
    var sheetData = [
        ['Nombre Proyecto',  'Campo de texto libre con el nombre del proyecto. Se incluye en el encabezado del PDF exportado.'],
        ['Anterior',         'Navega a la hoja previa del proyecto. Guarda automaticamente los datos del lazo activo.'],
        ['Hoja X / Y',       'Indicador de la hoja activa (X) sobre el total de hojas del proyecto (Y).'],
        ['Siguiente',        'Navega a la hoja siguiente. Si es la ultima hoja, simplemente permanece en ella.'],
        ['+ Anadir Nueva',   '[Login] Crea una nueva hoja en blanco al final del proyecto y navega directamente a ella.'],
        ['[X] Borrar Actual',  '[Login] Elimina permanentemente la hoja activa y todos sus lazos (pide confirmacion previa).'],
    ];
    y = table(sheetData, y, false);

    y = h2('Seleccionar Lazo — Botones 1 a 12', y+2, C.accent);
    y = intro('Cada hoja contiene hasta 12 lazos. Los botones numerados en el panel izquierdo permiten activar el lazo deseado. El color indica el estado de cada lazo:', y);
    var loopColor = [
        ['Azul (activo)',   'Es el lazo actualmente seleccionado y editable en la barra de parametros.'],
        ['Verde (con datos)','El lazo tiene datos: al menos el INST TAG esta relleno.'],
        ['Negro (vacio)',   'El lazo no tiene datos. Al seleccionarlo se muestra en blanco listo para rellenar.'],
    ];
    y = table(loopColor, y, false);

    y = h2('Gestion de Usuarios y Acceso', y+2, [180,80,0]);
    var userData = [
        ['Acceder',      'Abre el dialogo de login. Introduce usuario y contrasena para obtener acceso a las funciones protegidas.'],
        ['Canciones rest.','Con sesion iniciada se desbloquean: Duplicar, Borrar lazo, Anadir/Borrar hoja, PDF y DXF.'],
        ['Salir (usuario)','Cierra la sesion activa. El nombre del usuario actual se muestra en el boton. Los botones restringidos se bloquean de nuevo.'],
        ['Seguridad',    'Las credenciales no se almacenan en el navegador ni en el proyecto .json. Cada vez que se abre la aplicacion es necesario volver a iniciar sesion.'],
    ];
    y = table(userData, y, false);
    y = tip('La aplicacion permite trabajar con total normalidad sin iniciar sesion: ver diagramas, introducir parametros, navegar hojas y guardar/cargar el proyecto .json. Solo las acciones destructivas o de exportacion requieren autenticacion.', y+1);

    // ══════════════════════════════════════════════════════════════════════════
    // PAG 1 — INSTRUMENTO
    // ══════════════════════════════════════════════════════════════════════════
    newPage('Paso 1 — Instrumento');
    y=24; y=badge('PASO 1',margin,y)+3;
    y=h1('Configurar el Instrumento',y);
    y=intro('En la barra de parametros, el primer grupo es INSTRUMENTO. Es el punto de partida del lazo. Rellena los campos para definir el instrumento de campo y su cable de conexion.',y);
    y=table([
        ['INST TAG',     'Identificador unico del instrumento en el P&ID de planta',      'LT-100'],
        ['TIPO',         'Magnitud medida: Nivel, Caudal, Presion, Temperatura...',       'Nivel'],
        ['CATEGORIA',    'STD (2 hilos) / 3 Hilos / Valvula (6H) / Motor (8H)',          'STD'],
        ['BORNAS',       'Numeros de borna en la plaquita de bornas del instrumento',      '+, -'],
        ['HILOS',        'Color o codigo de conductores del cable 1 en cada borna',       'H1, H2'],
        ['CABLE 1 TAG',  'Nombre del cable campo->caja. Se autocompleta con "W"+TAG',    'WLT-100'],
        ['SECCION',      'Tipo y seccion del conductor del cable 1',                      '2x1.0mm2'],
        ['LONG. (m)',    'Longitud estimada del cable 1 en metros',                       '85'],
        ['Malla (M)',    'Marcar si el cable lleva pantalla de apantallamiento',           'Si'],
        ['Armadura (A)', 'Marcar si el cable lleva armadura de acero',                    'No'],
    ],y,true);
    y=tip('Al escribir el INST TAG el campo CABLE 1 TAG se rellena automaticamente con "W" + tag del instrumento.',y);
    y=tip('Los campos BORNAS e HILOS visibles cambian segun la CATEGORIA: 2 para STD, 3 para 3W, 6 para VALVE, 8 para MOTOR.',y+2,true);

    // ══════════════════════════════════════════════════════════════════════════
    // PAG 2 — CAJA JB
    // ══════════════════════════════════════════════════════════════════════════
    newPage('Paso 2 — Caja de Conexiones (JB)');
    y=24; y=badge('PASO 2',margin,y)+3;
    y=h1('Configurar la Caja de Conexiones (JB)',y);
    y=intro('El grupo CAJA permite activar una caja de conexiones (Junction Box) intermedia. Activala marcando el checkbox junto a JB TAG. El Cable 2 conecta la caja con el armario de marshalling.',y);
    y=table([
        ['JB TAG (cb)',  'Activa la caja JB y asigna su identificador unico en planta',   'JB-01'],
        ['BORNERO',      'Nombre de la regleta/modulo de bornas dentro de la caja',        'X1'],
        ['MAX BORNAS',   'Capacidad total de bornas de la caja (usado en vista Cajas)',    '20'],
        ['BORNAS CAJA',  'Numeros de borna donde se conecta este lazo en la caja',         '1, 2, PE'],
        ['Tierra (PE)',  'Borna de tierra/masa del bornero dentro de la caja',             'PE'],
        ['HILOS In+',    'Hilo conductor positivo que llega desde el campo al bornero',    'IN+'],
        ['HILOS Out+',   'Hilo conductor positivo que sale del bornero hacia marshalling', 'OUT+'],
        ['HILOS In-',    'Hilo conductor negativo de entrada a la caja',                   'IN-'],
        ['HILOS Out-',   'Hilo conductor negativo de salida de la caja',                   'OUT-'],
        ['HILOS InS',    'Hilo de malla/shield de entrada',                                'INS'],
        ['HILOS OutS',   'Hilo de malla/shield de salida',                                 'OUTS'],
        ['CABLE 2 TAG',  'Nombre del cable multipar caja->marshalling',                    'W-JB01'],
        ['SECCION',      'Tipo y seccion del cable multipar',                              '12x1.0mm2'],
        ['LONG. (m)',    'Longitud en metros del cable 2',                                 '120'],
        ['Malla/Armor.', 'Caracteristicas del cable 2',                                    'Si / Si'],
    ],y,true);
    y=tip('Si el lazo no pasa por JB, desmarca el checkbox: el grupo se atenuara y el Cable 2 desaparece del diagrama.',y);
    y=tip('MAX BORNAS se usa en la vista CAJAS para verificar que las prensaestopas caben en la base con separacion minima de 30mm.',y+2,true);

    // ══════════════════════════════════════════════════════════════════════════
    // PAG 3 — MARSHALLING
    // ══════════════════════════════════════════════════════════════════════════
    newPage('Paso 3 — Armario Marshalling');
    y=24; y=badge('PASO 3',margin,y)+3;
    y=h1('Configurar el Armario Marshalling',y);
    y=intro('El grupo MARSHALLING representa el armario de distribucion de senales, normalmente en sala de control. Activalo marcando el checkbox junto a MARSH TAG. El Cable 3 lo conecta con el armario de control (PLC/DCS).',y);
    y=table([
        ['MARSH TAG (cb)','Activa el armario marshalling y asigna su identificador',       'MCC-01'],
        ['BORNERO',       'Nombre de la regleta de bornas en el armario marshalling',      'X12'],
        ['MAX BORNAS',    'Capacidad maxima de bornas del armario marshalling',             '48'],
        ['BORNAS MARSH',  'Numeros de borna asignados a este lazo en el armario',          '5, 6, PE'],
        ['Tierra (PE)',   'Borna de tierra del bornero en el marshalling',                 'PE'],
        ['HILOS In+',     'Hilo positivo entrante: desde JB o campo si no hay JB',         'IN+'],
        ['HILOS Out+',    'Hilo positivo saliente hacia el armario de control (PLC)',       'OUT+'],
        ['HILOS In-',     'Hilo negativo de entrada al armario marshalling',               'IN-'],
        ['HILOS Out-',    'Hilo negativo de salida del armario marshalling',               'OUT-'],
        ['HILOS InS/OutS','Hilos de malla/shield de entrada y salida',                    'INS / OUTS'],
        ['CABLE 3 TAG',   'Nombre del cable marshalling->PLC (cable de sistema)',          'W-SYS01'],
        ['SECCION',       'Tipo y seccion del cable de sistema',                           '2x0.5mm2'],
        ['LONG. (m)',     'Longitud en metros del cable 3',                                '30'],
        ['Malla/Armor.',  'Caracteristicas del cable de sistema',                          'Si / No'],
    ],y,true);
    y=tip('Si la instalacion es directa campo->PLC sin marshalling, desmarca el checkbox. El Cable 3 desaparecera del diagrama y del listado de cables.',y);

    // ══════════════════════════════════════════════════════════════════════════
    // PAG 4 — CONTROL PLC
    // ══════════════════════════════════════════════════════════════════════════
    newPage('Paso 4 — Control Detallado (PLC)');
    y=24; y=badge('PASO 4',margin,y)+3;
    y=h1('Configurar el Control Detallado (PLC / DCS / SCADA)',y);
    y=intro('El grupo CONTROL define la conexion final en el armario de control. Se especifica la tarjeta de I/O, las bornas, los hilos y los nombres de las senales logicas en el sistema de supervision.',y);
    y=table([
        ['PLC TAG',      'Identificador del armario, rack o panel de control',             'PLC-01'],
        ['BORNERO',      'Regleta de bornas donde llega el cable de sistema (Cable 3)',    'X11'],
        ['DETALLES PLC', 'Texto libre multilínea: tarjeta I/O, rack, slot, canal, IP...', 'Rack0/Slot2/CH1'],
        ['BORNAS PLC',   'Bornas del modulo de I/O para cada hilo de la senal',           '1, 2, PE'],
        ['HILOS PLC',    'Color o codigo de conductores en la tarjeta I/O del PLC',       'H1, H2'],
        ['DESC. SENALES','Nombre de la senal en el sistema SCADA/PLC (tag de variable)',  'LT-100_PV'],
    ],y,true);
    y=tip('El campo DETALLES PLC es texto libre con varias lineas. Util para rack, slot, canal, tipo de tarjeta, IP del modulo, etc.',y);
    y=tip('El numero de BORNAS, HILOS y SENALES visibles depende de la CATEGORIA del instrumento.',y+2,true);
    y+=2;
    y=h2('Senales logicas segun categoria',y,C.accent);
    y=table([
        ['STD (2 hilos)', '1 senal analogica de proceso (tipico 4-20mA)',                              'TAG_PV'],
        ['3 Hilos',       '1 senal analogica de proceso para instrumentos de 3 hilos',                'TAG_PV'],
        ['Valvula (6H)',  '3 senales: apertura (CMD), feedback (FBK), posicion abierta (OPEN)',        'TAG_CMD, TAG_FBK, TAG_OPEN'],
        ['Motor (8H)',    '4 senales: marcha (RUN), paro (STOP), alarma (ALM), marcha confirmada (FB)','TAG_RUN, TAG_STOP, TAG_ALM, TAG_FB'],
    ],y,true);

    // ══════════════════════════════════════════════════════════════════════════
    // PAG 5 — RESULTADO Y EXPORTACION
    // ══════════════════════════════════════════════════════════════════════════
    newPage('Paso 5 — Resultado y Exportacion');
    y=24; y=badge('PASO 5',margin,y)+3;
    y=h1('Resultado, Gestion de Hojas y Exportacion',y);
    y=intro('Una vez completados todos los parametros, el diagrama se actualiza automaticamente en tiempo real en el canvas. A continuacion las opciones de gestion y exportacion disponibles.',y);
    y=h2('Gestion de Hojas y Lazos',y,C.accent);
    y=table([
        ['Nuevo lazo',    'Selecciona numero (1-12) en panel izquierdo y rellena los parametros del lazo'],
        ['Duplicar lazo', '[Login] Boton DUPLICAR: copia el lazo activo al siguiente hueco libre de la hoja'],
        ['Borrar lazo',   '[Login] Boton BORRAR: limpia completamente todos los datos del lazo activo'],
        ['Nueva hoja',    '[Login] Panel izq. > "+ Anadir Nueva Hoja": agrega una hoja en blanco al proyecto'],
        ['Hoja anterior', 'Boton ANTERIOR en panel izquierdo: va a la hoja previa del proyecto'],
        ['Hoja siguiente','Boton SIGUIENTE en panel izquierdo: va a la hoja siguiente del proyecto'],
        ['Borrar hoja',   '[Login] "[X] Borrar Hoja Actual" en panel izquierdo: elimina la hoja activa'],
    ],y,false);
    y=h2('Exportacion del Proyecto',y+2,[180,80,0]);
    y=table([
        ['Guardar',      'PROYECTO > Guardar: descarga el proyecto completo en formato .json'],
        ['Cargar',       'PROYECTO > Cargar: abre un archivo .json de proyecto guardado previamente'],
        ['PDF',          '[Login] EXPORTACION > PDF: exporta todas las hojas como PDF tecnico multi-pagina'],
        ['DXF',          '[Login] EXPORTACION > DXF: exporta los diagramas en formato DXF para AutoCAD/BricsCAD'],
        ['Lista Cables', 'VISTA > Lista Cables: tabla completa de cables con resumen por seccion y tipo'],
        ['Cajas',        'VISTA > Cajas: diagrama de distribucion de prensaestopas en cajas y marshalling'],
        ['CSV Cables',   'En Lista Cables > "Exportar Lista (.csv)": exporta el listado de cables a Excel'],
    ],y,false);
    y=tip('El proyecto se autoguarda automaticamente en localStorage cada vez que se modifica cualquier parametro. Al reabrir la app se restaura el ultimo estado sin necesidad de guardar manualmente.',y+2);
    y=tip('Las funciones marcadas con [Login] requieren login. Usar el boton ACCEDER del grupo USUARIO en la barra superior para autenticarse.',y+2,true);

    doc.save('CAE2026_Guia_de_Uso.pdf');
}

// Auto-init
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(initHelpModal, 150);
});
