@echo off
setlocal
echo ======================================================
echo   CAE 2026 - GENERADOR DE COPIA DE SEGURIDAD COMPLETA
echo ======================================================
echo.
echo Este script creara un archivo ZIP con todos los ficheros 
echo necesarios para ejecutar la aplicacion en otro ordenador 
echo (incluyendo estilos y librerias).
echo.

:: Obtener fecha para el nombre del archivo
set "mydate=%date:~-4%-%date:~3,2%-%date:~0,2%"
set "FILENAME=CAE_PROYECTO_COMPLETO_%mydate%.zip"

:: Comprimir ficheros usando PowerShell (disponible en todo Windows 10/11)
echo Comprimiendo archivos...
powershell -Command "Compress-Archive -Path 'index.html', 'style.css', 'script.js', 'jszip.min.js', 'jspdf.umd.min.js' -DestinationPath '%FILENAME%' -Force"

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ------------------------------------------------------
    echo  EXITO: Backup creado correctamente.
    echo  Archivo: %FILENAME%
    echo ------------------------------------------------------
    echo.
    echo Ya puedes enviar este archivo ZIP a otro PC.
) else (
    echo.
    echo ERROR: No se pudo crear el archivo ZIP. 
    echo Asegurate de no tener los archivos abiertos en otro programa.
)

echo.
pause
