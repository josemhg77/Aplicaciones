// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

// --- State Management ---
let extractedInstruments = [];
let originalPDFBytes = null;
let currentFileName = "";
let currentFileBlob = null;
let isLoggedIn = false;
let currentAnnotatedPdfUrl = null;
let selectedInstrumentTag = null;

// Credentials
const AUTH_USER = "jmg";
const AUTH_PASS = "4321";
const AUTH_USER_2 = "TRESCA";
const AUTH_PASS_2 = "TRESCA";

// Catálogo ISA Extendido y Detallado (Base para buscar)
const DEFAULT_MAPPINGS = {
    'PIT': 'Transmisor Indicador de Presión',
    'FIT': 'Transmisor Indicador de Caudal',
    'TIT': 'Transmisor Indicador de Temperatura',
    'LIT': 'Transmisor Indicador de Nivel',
    'PT': 'Transmisor de Presión',
    'PI': 'Indicador de Presión',
    'PCV': 'Válvula Control de Presión',
    'TT': 'Transmisor de Temperatura',
    'TI': 'Indicador de Temperatura',
    'TCV': 'Válvula Control de Temp.',
    'FT': 'Transmisor de Caudal',
    'FI': 'Indicador de Caudal',
    'FCV': 'Válvula Control de Caudal',
    'LT': 'Transmisor de Nivel',
    'LI': 'Indicador de Nivel',
    'LCV': 'Válvula Control de Nivel',
    'DPS': 'Interruptor Presión Diferencial',
    'DPT': 'Transmisor Presión Diferencial',
    'PDT': 'Transmisor Presión Diferencial',
    'MD': 'Compuerta Motorizada',
    'EV': 'Electroválvula',
    'FCU': 'Fancoil Unit',
    'FC': 'Unidad de Control (Fancoil)',
    'EC': 'Elemento de Control',
    'P': 'Bomba (Pump)',
    'M': 'Motor',
    'K': 'Compresor',
    'C': 'Compresor',
    'FN': 'Ventilador (Fan)',
    'HV': 'Válvula Manual',
    'XV': 'Válvula de Corte',
    'CV': 'Válvula de Control Genérica',
    'SV': 'Válvula Solenoide',
    'ZV': 'Válvula de Estado/Corte',
    'UV': 'Válvula Multi-función',
    'TE': 'Elemento de Temp. / Termopozo',
    'FE': 'Elemento de Caudal',
    'PE': 'Elemento de Presión',
    'LE': 'Elemento de Nivel',
    'PSH': 'Presostato (Alta)',
    'PSL': 'Presostato (Baja)',
    'TSH': 'Termostato (Alta)',
    'TSL': 'Termostato (Baja)',
    'LSH': 'Nivelostato (Alta)',
    'LSL': 'Nivelostato (Baja)',
    'FSH': 'Flujostato (Alta)',
    'FSL': 'Flujostato (Baja)',
    'ZT': 'Transmisor de Posición',
    'ZSC': 'Interruptor Posición (Cerrado)',
    'ZSO': 'Interruptor Posición (Abierto)',
    'HY': 'Actuador / Compuerta',
    'BD': 'Compuerta (Blowdown/Damper)',
    'VFD': 'Variador de Frecuencia'
};

let projectMappings = DEFAULT_MAPPINGS;

// Optionally merge saved ones with our new default ones:
let savedMap = JSON.parse(localStorage.getItem('pid_mappings_user_v5'));
if (savedMap) {
    projectMappings = Object.assign({}, DEFAULT_MAPPINGS, savedMap);
}
localStorage.setItem('pid_mappings_user_v5', JSON.stringify(projectMappings));

// --- DOM Elements ---
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const loader = document.getElementById('loader');
const loaderText = document.getElementById('loader-text');
const uploadContent = document.getElementById('upload-content');
const tableBody = document.getElementById('table-body');
const exportBtn = document.getElementById('export-btn');
const countBadge = document.getElementById('count-badge');
const filterInput = document.getElementById('filter-input');
const notification = document.getElementById('notification');

// Config Modal Elements (Now Sidebar)
const configBody = document.getElementById('config-body');
const importConfigTrigger = document.getElementById('import-config-trigger');
const importConfigFile = document.getElementById('import-config-file');

// Top Toolbar Elements
const saveConfigBtnTop = document.getElementById('save-config-btn-top');
const uploadNewPdfBtnTop = document.getElementById('upload-new-pdf-btn-top');
const downloadAnnotatedBtnTop = document.getElementById('download-annotated-btn-top');

// Login Elements
const loginModal = document.getElementById('login-modal');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const openLoginBtn = document.getElementById('open-login-btn');
const closeLoginBtn = document.getElementById('close-login-btn');
const logoutBtn = document.getElementById('logout-btn');
const userLoggedInSpan = document.getElementById('user-logged-in');

// --- Initialization ---
lucide.createIcons();

// --- Login Logic ---
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const user = usernameInput.value;
    const pass = passwordInput.value;

    if ((user === AUTH_USER && pass === AUTH_PASS) || (user.toUpperCase() === AUTH_USER_2 && pass === AUTH_PASS_2)) {
        isLoggedIn = true;
        loginModal.style.opacity = '0';
        setTimeout(() => {
            loginModal.style.display = 'none';
            loginModal.style.opacity = '1'; // Reset for next time if needed
            updateButtonLockStatus();
        }, 300);
        openLoginBtn.style.display = 'none';
        userLoggedInSpan.style.display = 'flex'; // Usar flex para mantener alineación de iconos
        
        const nameDisplay = document.getElementById('logged-username-display');
        if (nameDisplay) nameDisplay.textContent = `Usuario: ${user}`;
        
        showNotification(`Bienvenido, ${user}`);
    } else {
        loginError.style.display = 'block';
        passwordInput.value = "";
    }
});

openLoginBtn.addEventListener('click', () => {
    loginModal.style.display = 'flex';
    loginError.style.display = 'none';
    usernameInput.focus();
});

closeLoginBtn.addEventListener('click', () => {
    loginModal.style.display = 'none';
});

logoutBtn.addEventListener('click', () => {
    isLoggedIn = false;
    openLoginBtn.style.display = 'flex';
    userLoggedInSpan.style.display = 'none';
    updateButtonLockStatus();
    showNotification("Sesión cerrada");
});

function updateButtonLockStatus() {
    // Select all buttons that should be locked/unlocked
    const lockableElements = document.querySelectorAll('.lockable');

    lockableElements.forEach(el => {
        const lockIcon = el.querySelector('.lock-icon');
        
        if (isLoggedIn) {
            // Always enable if logged in, so they don't look "dead"
            el.disabled = false;
            
            // Visual unlocking
            el.classList.remove('btn-locked');
            if (lockIcon) lockIcon.style.display = 'none';
        } else {
            // Hard lock
            el.disabled = true;
            el.classList.add('btn-locked');
            if (lockIcon) lockIcon.style.display = 'inline-block';
        }
    });

    lucide.createIcons();
}

// Ensure locked buttons trigger login if clicked (for those that might be focusable or custom)
document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn-locked');
    if (btn && !isLoggedIn) {
        e.preventDefault();
        e.stopPropagation();
        loginModal.style.display = 'flex';
        showNotification("Inicia sesión para desbloquear esta función");
    }
}, true); // Use capture to intercept before other listeners

// --- Copy & Right-Click Prevention ---
document.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.no-copy')) {
        e.preventDefault();
        showNotification("Copia de datos restringida");
    }
});

document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        const selection = window.getSelection().toString();
        if (selection) {
            e.preventDefault();
            showNotification("Copia de texto restringida");
        }
    }
});

// --- Drag & Drop ---
dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'application/pdf') handlePDF(file);
});
fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) handlePDF(file);
});
uploadNewPdfBtnTop.addEventListener('click', () => fileInput.click());

// --- PDF Processing ---
async function handlePDF(file) {
    if (!file) return;
    currentFileBlob = file;
    showLoader(true, "Buscando equipos por catálogo e IA espacial...");
    currentFileName = file.name;
    
    try {
        originalPDFBytes = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: originalPDFBytes.slice(0) }).promise;
        const allData = [];
        
        // Allowed prefixes from the config (ordered longest first to prevent P intercepting PT)
        const prefixes = Object.keys(projectMappings).map(p => p.trim().toUpperCase()).filter(p => p.length > 0).sort((a, b) => b.length - a.length);
        
        if (prefixes.length === 0) {
            showNotification('Error: El catálogo está vacío. Añade tipos primero.');
            showLoader(false);
            return;
        }

        const escapeRegExp = (string) => string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        
        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const textContent = await page.getTextContent();
            const viewport = page.getViewport({ scale: 1.0 });

            // Pure strings from PDF
            const items = textContent.items;

            const pagePrefixes = [];
            const pageNumbers = [];

            // A helper to safely push tags checking for duplicates in the same physical space
            function pushTag(tag, prefix, itemObj) {
                const isDupe = allData.some(d => d.tag === tag && Math.abs(d.y - itemObj.transform[5]) < 8 && Math.abs(d.x - itemObj.transform[4]) < 8);
                if (!isDupe) {
                    allData.push({
                        tag: tag,
                        prefix: prefix,
                        page: i,
                        x: itemObj.transform[4],
                        y: itemObj.transform[5],
                        width: itemObj.width || 25,
                        height: itemObj.height || 10,
                        viewHeight: viewport.height
                    });
                }
            }
            
            items.forEach(item => {
                const text = item.str.trim();
                let cleanText = text.replace(/[^A-Za-z0-9\-\.]/g, ''); // strip invisible spaces
                if (!cleanText) return;

                // 1. Is it EXACTLY a prefix? (e.g., "TT", "MD", "DPS", "FCU")
                if (prefixes.includes(cleanText.toUpperCase())) {
                    pagePrefixes.push({ text: cleanText.toUpperCase(), item });
                    return;
                }
                
                // 2. Is it EXACTLY a tag number? (e.g., "20-01", "1001", "20.02") 
                // Matches digits potentially with hyphens or dots anywhere
                if (/^[\d]+[\-\.]?[\d]+[A-Z]?$/.test(cleanText) || /^[\d]+[A-Z]?$/.test(cleanText)) {
                    pageNumbers.push({ text: cleanText, item });
                    return;
                }

                // 3. Is it a combined inline tag? (e.g., "EV-20-01", "20-01 TT", "DPS20-04")
                prefixes.forEach(pref => {
                    const esc = escapeRegExp(pref);
                    // Match Prefix-Number: Prefix + optional delimiter + 1-6 digits + optional [-.] + digits + optional 1-2 letters
                    const regexForward = new RegExp(`(?:^|[^A-Z])(${esc}[\\s\\-\\.]?\\d{1,6}(?:[\\-\\.]\\d{1,5})?[A-Z]{0,2})(?=[^A-Z]|$)`, 'g');
                    // Match Number-Prefix: Digits + optional delimiter + Prefix
                    const regexBackward = new RegExp(`(?:^|[^A-Z])(\\d{1,6}(?:[\\-\\.]\\d{1,5})?[A-Z]{0,2}[\\s\\-\\.]?${esc})(?=[^A-Z]|$)`, 'g');

                    let match;
                    while ((match = regexForward.exec(text.toUpperCase())) !== null) {
                        let result = match[1].replace(/\s+/g, '-');
                        if (!result.includes('-')) result = result.replace(pref, pref + '-');
                        pushTag(result, pref, item);
                    }
                    while ((match = regexBackward.exec(text.toUpperCase())) !== null) {
                        let result = match[1].replace(/\s+/g, '-');
                        // Transform NUM-PREFIX to PREFIX-NUM
                        const numPart = result.replace(pref, '').replace(/^-|-$/g, '');
                        pushTag(`${pref}-${numPart}`, pref, item);
                    }
                });
            });

            // 4. SPATIAL ALGORITHMS: Combine floating prefixes with nearest floating numbers
            pagePrefixes.forEach(prefObj => {
                const px = prefObj.item.transform[4];
                const py = prefObj.item.transform[5];
                
                let closestNum = null;
                // Maximum radius to search for a pair (experimentally, 40-50 units is good for adjacent text in P&IDs)
                let minDist = 45; 

                pageNumbers.forEach(numObj => {
                    const nx = numObj.item.transform[4];
                    const ny = numObj.item.transform[5];
                    // Euclidean distance calculating 2D proximity
                    const dist = Math.hypot(px - nx, py - ny);
                    if (dist < minDist) {
                        minDist = dist;
                        closestNum = numObj;
                    }
                });

                if (closestNum) {
                    // We found a floating prefix and a floating number close to each other!
                    const finalTag = `${prefObj.text}-${closestNum.text}`;
                    pushTag(finalTag, prefObj.text, prefObj.item);
                }
            });
        }
        
        processInstruments(allData);
        showNotification('Procesamiento completado usando el catálogo y vinculación espacial.');
    } catch (error) {
        console.error("PDF Processing Error:", error);
        showNotification('Error crítico al leer el PDF. Verifica que contenga texto válido.');
    } finally {
        showLoader(false);
    }
}

function processInstruments(data) {
    selectedInstrumentTag = null;
    const uniqueMap = new Map();
    const allTags = data.map(i => i.tag.toUpperCase());

    data.forEach(item => {
        // Find configuration mapping description based on captured exact prefix
        const mappedType = projectMappings[item.prefix.toUpperCase()] || 'Instrumento / Equipo';
        const normalizedTag = item.tag.replace(/\s+/g, '-').toUpperCase();
        
        // Count how many times this tag appears physically across the document data (approximate duplicate check)
        const occurrences = allTags.filter(t => t === item.tag.toUpperCase()).length;
        
        // Determinar indicación local basada en si el prefijo tiene una I (ej: PIT, FIT)
        const hasLocalIndication = item.prefix.toUpperCase().includes('I') ? 'Sí' : 'No';
        
        if (!uniqueMap.has(normalizedTag)) {
            uniqueMap.set(normalizedTag, {
                tag: item.tag.toUpperCase(), // Display version
                tipo: mappedType,
                conexion: '',
                indicacion: hasLocalIndication,
                hoja: item.page,
                ubicaciones: [],
                isDuplicate: false
            });
        }
        
        const entry = uniqueMap.get(normalizedTag);
        entry.ubicaciones.push({
            page: item.page,
            x: item.x,
            y: item.y,
            w: item.width,
            h: item.height,
            vh: item.viewHeight
        });

        // If it was found at more than 1 distinct physical coordinate (ubicaciones > 1), mark as duplicate
        if (entry.ubicaciones.length > 1) {
            entry.isDuplicate = true;
        }
    });
    
    // Sort array alphabetically by tag
    extractedInstruments = Array.from(uniqueMap.values()).sort((a, b) => a.tag.localeCompare(b.tag));
    renderTable(extractedInstruments);
    
    if (extractedInstruments.length === 0) {
        showNotification("Ningún equipo detectado con la configuración actual.");
    }
    
    document.getElementById('workspace').style.display = 'flex';
    dropZone.style.display = 'none';
    updateButtonLockStatus();
    renderPDFPreview(); // Show PDF in the UI
}

// --- Table Rendering ---
function renderTable(data) {
    tableBody.innerHTML = '';
    data.forEach((item, index) => {
        const tr = document.createElement('tr');
        
        // Determinar color de la fila, incluyendo si está seleccionada
        let trStyle = item.isDuplicate ? 'background-color: rgba(239, 68, 68, 0.2); border-left: 3px solid #ef4444;' : '';
        if (selectedInstrumentTag === item.tag) {
            trStyle = 'background-color: rgba(59, 130, 246, 0.15); border-left: 3px solid #3b82f6;';
        }
        
        const tagStyle = item.isDuplicate ? 'color: #ffcccc;' : '';
        
        tr.style = trStyle;
        tr.style.cursor = 'pointer';
        tr.setAttribute('data-tag', item.tag);
        tr.setAttribute('data-duplicate', item.isDuplicate ? 'true' : 'false');
        
        tr.innerHTML = `
            <td>
                <span class="tag-badge" style="letter-spacing:1px; ${tagStyle}" title="${item.isDuplicate ? 'TAG DUPLICADO EN EL PLANO' : ''}">
                    ${item.tag}
                    ${item.isDuplicate ? '<i data-lucide="alert-triangle" style="width: 14px; height: 14px; color: #ef4444; margin-left: 5px;"></i>' : ''}
                </span>
            </td>
            <td><input type="text" class="editable-cell" value="${item.tipo}" onchange="updateData('${item.tag}', 'tipo', this.value)"></td>
            <td>
                <select class="editable-cell" onchange="updateData('${item.tag}', 'conexion', this.value)">
                    <option value="" ${item.conexion === '' ? 'selected' : ''}>-</option>
                    <option value="Roscada" ${item.conexion === 'Roscada' ? 'selected' : ''}>Roscada</option>
                    <option value="Brida" ${item.conexion === 'Brida' ? 'selected' : ''}>Brida</option>
                </select>
            </td>
            <td><select class="editable-cell" onchange="updateData('${item.tag}', 'indicacion', this.value)">
                <option value="Sí" ${item.indicacion === 'Sí' ? 'selected' : ''}>Sí</option>
                <option value="No" ${item.indicacion === 'No' ? 'selected' : ''}>No</option>
            </select></td>
            <td><input type="text" class="editable-cell" value="${item.hoja}" onchange="updateData('${item.tag}', 'hoja', this.value)"></td>
            <td><button class="icon-btn delete-instrument" data-tag="${item.tag}" style="color:#ef4444; border-color:transparent;" title="Eliminar"><i data-lucide="trash-2"></i></button></td>
        `;
        
        // Listener para seleccionar al hacer clic en la fila
        tr.addEventListener('click', (e) => {
            // Ignorar clics en los elementos interactivos
            if (['INPUT', 'SELECT', 'BUTTON'].includes(e.target.tagName) || e.target.closest('button')) return;
            
            if (selectedInstrumentTag === item.tag) {
                selectedInstrumentTag = null; // Quitar selección
            } else {
                selectedInstrumentTag = item.tag;
            }
            
            // Actualizar visual de la tabla sin reescribir HTML para no perder el foco
            Array.from(tableBody.querySelectorAll('tr')).forEach(row => {
                const rTag = row.getAttribute('data-tag');
                const rDup = row.getAttribute('data-duplicate') === 'true';
                let rStyle = rDup ? 'background-color: rgba(239, 68, 68, 0.2); border-left: 3px solid #ef4444;' : '';
                if (selectedInstrumentTag === rTag) {
                    rStyle = 'background-color: rgba(59, 130, 246, 0.15); border-left: 3px solid #3b82f6;';
                }
                row.style = rStyle;
                row.style.cursor = 'pointer';
            });
            
            renderPDFPreview();
        });
        
        tableBody.appendChild(tr);
    });
    countBadge.textContent = data.length;
    lucide.createIcons();

    // Attach delete listeners
    document.querySelectorAll('.delete-instrument').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const tagToDelete = e.currentTarget.getAttribute('data-tag');
            const globalIdx = extractedInstruments.findIndex(i => i.tag === tagToDelete);
            
            if (globalIdx > -1) {
                extractedInstruments.splice(globalIdx, 1);
            }
            
            if (selectedInstrumentTag === tagToDelete) {
                selectedInstrumentTag = null;
            }
            
            const term = document.getElementById('filter-input').value.toUpperCase();
            const filtered = extractedInstruments.filter(i => i.tag.toUpperCase().includes(term));
            
            renderTable(filtered); 
            renderPDFPreview(); 
        });
    });
}

// --- PDF Previewing in UI ---
async function renderPDFPreview() {
    const container = document.getElementById('pdf-viewer-container');
    if (!container) return;

    const existingIframe = container.querySelector('iframe');
    if (!existingIframe) {
        container.innerHTML = '<div class="loader-overlay active" style="position:absolute; background: transparent; display:flex;"><div class="spinner"></div></div>';
    } else {
        container.style.cursor = 'wait';
    }
    
    try {
        // Robust access to PDFLib
        const lib = (typeof window.PDFLib !== 'undefined') ? window.PDFLib : (typeof PDFLib !== 'undefined' ? PDFLib : null);
        if (!lib) throw new Error("PDFLib library not found");

        const { PDFDocument, rgb } = lib;
        const pdfDoc = await PDFDocument.load(originalPDFBytes.slice(0));
        const pages = pdfDoc.getPages();
        
        const drawCircles = (inst, isSelected) => {
            inst.ubicaciones.forEach(loc => {
                const page = pages[loc.page - 1];
                if (!page) return;
                
                const centerX = loc.x + (loc.w / 2);
                const centerY = loc.y + (loc.h / 2);
                const radius = Math.max(loc.w, loc.h, 25) / 1.5;
                
                const bColor = isSelected ? rgb(0.14, 0.40, 0.96) : rgb(1, 0, 0); // Azul o Rojo
                const bWidth = isSelected ? 4 : 2;
                
                page.drawCircle({
                    x: centerX,
                    y: centerY, 
                    size: radius + (isSelected ? 2 : 0),
                    borderColor: bColor,
                    borderWidth: bWidth,
                    opacity: 0.7
                });
            });
        };
        
        // Dibujamos primero los no seleccionados
        extractedInstruments.forEach(inst => {
            if (inst.tag !== selectedInstrumentTag) drawCircles(inst, false);
        });
        
        // Dibujamos el seleccionado encima y de otro color
        extractedInstruments.forEach(inst => {
            if (inst.tag === selectedInstrumentTag) drawCircles(inst, true);
        });
        
        const modifiedPdfBytes = await pdfDoc.save();
        const blob = new Blob([modifiedPdfBytes], { type: 'application/pdf' });
        
        if (currentAnnotatedPdfUrl) {
            URL.revokeObjectURL(currentAnnotatedPdfUrl);
        }
        currentAnnotatedPdfUrl = URL.createObjectURL(blob);
        
        if (existingIframe) {
            existingIframe.src = `${currentAnnotatedPdfUrl}#toolbar=0&navpanes=0&view=FitH`;
        } else {
            container.innerHTML = `<iframe src="${currentAnnotatedPdfUrl}#toolbar=0&navpanes=0&view=FitH" style="width: 100%; height: 100%; border: none; border-radius: 0 0 16px 16px;"></iframe>`;
        }

    } catch (e) {
        console.error("PDF Preview Error:", e);
        container.innerHTML = `<p style="color:var(--text-secondary); text-align:center; padding: 40px;">Error al generar vista previa: ${e.message}</p>`;
    } finally {
        container.style.cursor = 'default';
    }
}

window.updateData = (tag, field, value) => {
    const inst = extractedInstruments.find(i => i.tag === tag);
    if (inst) {
        inst[field] = value;
    }
};

// --- Excel Export & Download ---
downloadAnnotatedBtnTop.addEventListener('click', () => {
    if (!isLoggedIn) {
        loginModal.style.display = 'flex';
        showNotification("Inicia sesión para descargar el PDF verificado");
        return;
    }
    if (extractedInstruments.length === 0 || !currentAnnotatedPdfUrl) {
        showNotification("No hay datos para generar el PDF marcado");
        return;
    }
    const link = document.createElement('a');
    link.href = currentAnnotatedPdfUrl;
    link.download = `Marcas_P&ID_${currentFileName}`;
    document.body.appendChild(link); // Append to body for compatibility
    link.click();
    document.body.removeChild(link);
});

exportBtn.addEventListener('click', () => {
    if (!isLoggedIn) {
        loginModal.style.display = 'flex';
        showNotification("Inicia sesión para exportar a Excel");
        return;
    }
    if (extractedInstruments.length === 0) {
        showNotification("No hay datos detectados para exportar");
        return;
    }
    const worksheet = XLSX.utils.json_to_sheet(extractedInstruments.map(i => ({
        'Tag': i.tag,
        'Tipo': i.tipo,
        'Conexión Proceso': i.conexion,
        'Ind. Local': i.indicacion,
        'Hoja': i.hoja,
        'Advertencia': i.isDuplicate ? 'REPETIDO' : ''
    })));
    
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Instrumentos");
    
    const wscols = [ {wch:15}, {wch:35}, {wch:20}, {wch:10}, {wch:10}, {wch:15} ];
    worksheet['!cols'] = wscols;
    
    XLSX.writeFile(workbook, `Lista_Equipos_${currentFileName.replace('.pdf', '')}.xlsx`);
});

// --- Config Sidebar Logic ---
function renderConfigRows() {
    configBody.innerHTML = '';
    const sortedEntries = Object.entries(projectMappings).sort((a,b) => a[0].localeCompare(b[0]));
    sortedEntries.forEach(([pref, desc]) => {
        addConfigRow(pref, desc);
    });
}

function addConfigRow(pref = '', desc = '') {
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><input type="text" class="config-input pref" maxlength="5" value="${pref.trim()}" placeholder="Ej: PIT"></td>
        <td><input type="text" class="config-input desc" value="${desc}" placeholder="Ej: Transmisor Presión"></td>
        <td><button class="delete-row-btn" onclick="this.closest('tr').remove()"><i data-lucide="trash-2"></i></button></td>
    `;
    configBody.appendChild(tr);
    lucide.createIcons();
}

// Ensure the plus button works (since we removed its specific variable)
document.getElementById('add-config-row')?.addEventListener('click', () => addConfigRow());

saveConfigBtnTop.addEventListener('click', () => {
    const newMappings = {};
    configBody.querySelectorAll('tr').forEach(row => {
        const pref = row.querySelector('.pref').value.trim().toUpperCase();
        const desc = row.querySelector('.desc').value.trim();
        if (pref) {
            newMappings[pref] = desc;
        }
    });
    
    if(Object.keys(newMappings).length === 0) {
        showNotification("No puedes dejar el catálogo vacío.");
        return;
    }
    
    // Save to local logic memory
    projectMappings = newMappings;
    localStorage.setItem('pid_mappings_user_v5', JSON.stringify(projectMappings));
    
    // Download physically as JSON
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(projectMappings, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "pid_catalogo_isa_backup.json");
    downloadAnchorNode.click();
    downloadAnchorNode.remove();

    showNotification('Catálogo guardado localmente y exportado.');
    
    // Reprocesar el plano automáticamente si hay uno cargado para aplicar cambios del nuevo catálogo
    if (currentFileBlob) {
        handlePDF(currentFileBlob);
    }
});

importConfigTrigger.addEventListener('click', () => importConfigFile.click());

importConfigFile.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const imported = JSON.parse(event.target.result);
            projectMappings = imported;
            localStorage.setItem('pid_mappings_v2', JSON.stringify(projectMappings));
            renderConfigRows();
            showNotification('Catálogo importado con éxito');
        } catch (err) {
            showNotification('Error al importar JSON');
        }
    };
    reader.readAsText(file);
});

// Search Filter
filterInput.addEventListener('input', (e) => {
    const term = e.target.value.toUpperCase();
    const filtered = extractedInstruments.filter(i => i.tag.toUpperCase().includes(term));
    renderTable(filtered);
});

// Resizable & Sortable Table logic
let currentSortCol = null;
let currentSortDir = 'asc';

document.querySelectorAll('.resizable-th').forEach(th => {
    // Sorting listener
    th.addEventListener('click', (e) => {
        if(e.target.classList.contains('resizer')) return; // Ignore clicks on the resize handle
        const sortKey = th.getAttribute('data-sort');
        if(!sortKey) return;
        
        if(currentSortCol === sortKey) {
            currentSortDir = currentSortDir === 'asc' ? 'desc' : 'asc';
        } else {
            currentSortCol = sortKey;
            currentSortDir = 'asc';
        }

        const sorted = [...extractedInstruments].sort((a,b) => {
            let valA = a[sortKey] || '';
            let valB = b[sortKey] || '';
            return currentSortDir === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        });
        extractedInstruments = sorted;
        renderTable(sorted);
    });

    // Resizing listener
    const resizer = th.querySelector('.resizer');
    if(!resizer) return;
    
    let x = 0;
    let w = 0;

    const mouseMoveHandler = function(e) {
        const dx = e.clientX - x;
        th.style.width = `${w + dx}px`;
    };
    const mouseUpHandler = function() {
        resizer.classList.remove('resizing');
        document.removeEventListener('mousemove', mouseMoveHandler);
        document.removeEventListener('mouseup', mouseUpHandler);
    };

    resizer.addEventListener('mousedown', function(e) {
        x = e.clientX;
        w = th.getBoundingClientRect().width;
        
        resizer.classList.add('resizing');
        document.addEventListener('mousemove', mouseMoveHandler);
        document.addEventListener('mouseup', mouseUpHandler);
    });
});

// Layout Resizing Logic
function initPanelResizer(resizerId, leftElementId) {
    const resizer = document.getElementById(resizerId);
    const leftEl = document.getElementById(leftElementId);
    if (!resizer || !leftEl) return;
    
    let isResizing = false;
    let lastDownX = 0;
    let leftWidth = 0;

    const mouseMoveHandler = (e) => {
        if (!isResizing) return;
        const dx = e.clientX - lastDownX;
        const newWidth = Math.max(200, leftWidth + dx); // min width 200px
        leftEl.style.width = `${newWidth}px`;
        leftEl.style.flex = 'none'; // Overwrite flex grow if it has it so width is respected
    };

    const mouseUpHandler = () => {
        if (isResizing) {
            isResizing = false;
            resizer.classList.remove('resizing');
            document.body.style.cursor = 'default';
            // Restore iframe pointer events
            document.querySelectorAll('iframe').forEach(ifr => ifr.style.pointerEvents = 'auto');
            
            document.removeEventListener('mousemove', mouseMoveHandler);
            document.removeEventListener('mouseup', mouseUpHandler);
        }
    };

    resizer.addEventListener('mousedown', (e) => {
        isResizing = true;
        lastDownX = e.clientX;
        leftWidth = leftEl.getBoundingClientRect().width;
        
        resizer.classList.add('resizing');
        document.body.style.cursor = 'col-resize';
        // Prevent iframes from swallowing mouse events
        document.querySelectorAll('iframe').forEach(ifr => ifr.style.pointerEvents = 'none');
        
        document.addEventListener('mousemove', mouseMoveHandler);
        document.addEventListener('mouseup', mouseUpHandler);
    });
}
initPanelResizer('resizer-sidebar', 'main-sidebar');
initPanelResizer('resizer-pdf', 'main-table-panel');

// Helpers
function showLoader(show, text = "Procesando...") {
    loaderText.textContent = text;
    if (show) loader.classList.add('active');
    else loader.classList.remove('active');
}

function showNotification(text) {
    notification.textContent = text;
    notification.classList.add('show');
    setTimeout(() => notification.classList.remove('show'), 4000);
}

// Inicializar el panel lateral y estados de bloqueo
renderConfigRows();
updateButtonLockStatus();
